//
//  main.cpp
//  UsoSwitch
//
//  Created by Juan Cisneros on 5/5/21.
//

#include <iostream>
using namespace::std;

int main() {
    
    //SWITCH CONDICIONAL MULTIPLE
    //LIMITANTES: evalua el valor de una variable, ejecuta en funcion a ese valor.
    
    //Declaracion e input de variables
    char a;
    cin >> a;
    
    switch (a) {
        case 'a':
            cout << "INGRESO a"<<endl;
            break;
        case 'b':
            cout << "INGRESO b" << endl;
            break;
        case 'c':
        case 'd':
            cout << "INGRESO c o d" << endl;
            break;
            
        default:
            cout << "NUMERO INGRESADO DISTINTO A a-d" <<endl;
            break;
    }
    
    
    
    
    
    
    return 0;
}
