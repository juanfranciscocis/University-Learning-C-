//
//  main.cpp
//  FUNCIONES SET Y GET
//
//  Created by Juan Cisneros on 3/31/21.
//

#include <iostream>
#include <string>
using namespace::std;

class Smartphone{
    
public:
    
    //FUNCIONES SET
    
    //CONSTRUCTOR : FUNCION MIEMBRO QUE PERMITE INICIALIZAR LOS OBJETOS
        //NO TIENE TIPO DE RETORNO
        //MISMO NOMBRE DE LA CLASE
        //PARAMETROS IGUALES A LOS DATOS MIEMBRO (PRIVATE), EL NOMBRE DE ESTOS IGUALES A LOS DE LAS FUNCIONES SET
    Smartphone (string brand, string model, float price)
    :marca(brand),modelo(model), precio(price) //DATO MIEMBRO Y EL PARAMETRO ENTRE PARENTESIS
    //INICIALIZA LOS DATOS MIEMBRO CON LOS VALORES DE LOS PARAMETROS
        //LISTA INICIALIZADORA
    {
        //Cuerpo Vacio, AVECES USAMOS FUNCIONES SET DENTRO DE ESTE!
    }
    
    
    
    
   
    //Funcion setMarca, se asigna el valor a la marca
    void setMarca (string brand){
        marca =brand;
    }
    
    
    //Funcion setModelo
    void setModelo (string model){
        modelo = model;
    }
    
    //Funcion setPrecio
    
    void setPrecio (float price){
        precio = price;
    }

    
    //FUNCIONES GET
    
    string getMarca ()const{
        return marca;
    }
    
    string getModelo() const{
        return modelo;
    }
    
    float getPrecio()const{
        return precio;
    }
    
    
    //FUNCION QUE MUESTRE LOS DATIS DEL OBJETO
    
    void datosSmartphone () const{
        cout << "MARCA: " <<getMarca()<<endl;
        cout << "MODELO: " <<getModelo()<<endl;
        cout << "PRECIO: $" << getPrecio()<<endl;
        
        
    }
    
    
    
    
    
    
private:
    string marca;
    string modelo;
    float precio;
    
    
};


int main() {
    

    //Crear un objeto de la clase
    Smartphone sp1("","",0);//USO DEL CONSTRUCTOR PARA INICIALIZAR MIS DATOS MIEMBRO
    sp1.datosSmartphone();//MUESTRO QUE LOS DATOS MIEMBROS ESTAN ASIGANDOS A ESPACIOS EN BLANCO Y 0
    
    
    
    
    //PEDIR AL USUARIO VALORES PARA SUS DATOS MIEMBRO
    //DEFINO VARIABLES
    
    string marca;
    string modelo;
    float precio;
    
    cout << "INGRESE LA MARCA"<<endl;
    getline(cin, marca);
    
    cout << "INGRESE EL PRECIO"<<endl;
    cin >> precio;
    
    cin.ignore(); //ignoro el enter que deja el usuario
    
    
    cout << "INGRESE EL MODELO"<<endl;
    getline(cin, modelo);
    

    
    
    //  ASIGNAR LOS VALORES INGRESADOS A LOS DATOS MIEMBRO DEL OBJETO
    
    sp1.setMarca(marca);
    sp1.setModelo(modelo);
    sp1.setPrecio(precio);
    
    //MUESTRO LA CLASE
    
    sp1.datosSmartphone();
    
    
    
    
    
    
    
    
    
    
    
    return 0;
}
