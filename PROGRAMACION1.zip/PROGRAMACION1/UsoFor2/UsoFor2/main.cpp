//
//  main.cpp
//  UsoFor2
//
//  Created by Juan Cisneros on 5/5/21.
//

#include <iostream>
using namespace std;

int main() {
    
    /*int sum = 0;

    for(int i=1;i<=10;i++){
        
        sum+=3*i;
        
        
    }
    
    cout<< "SUMA: "<<sum<<endl;
    */
     
     //SENTENCIA BREAK
    

    for(int i=1;i<=10;i++){
        
        if(i==5){
            break;
        }
        
        cout << i << endl;
        
        
    }
    
    //SENTENCIA CONTINUE
    
    for(int i=1;i<=10;i++){
        
        if(i==5){
            continue;
        }
        
        cout << i << endl;
        
        
    }
    
     
    
    

    return 0;
}
