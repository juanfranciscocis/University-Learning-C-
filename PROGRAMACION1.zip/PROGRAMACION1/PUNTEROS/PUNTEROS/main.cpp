//
//  main.cpp
//  PUNTEROS
//
//  Created by Juan Cisneros on 5/10/21.
//




#include <iostream>
using namespace std;
//VARIABLE : Ubicacion de memoria que contiene un valor
//PUNTEROS : REFERENCIA INDIRECTA A UN VALOR (NO CONTIENE EL VALOR DE UNA VARIABLE SI NO LA DIRECCION DE MEMORIA DONDE SE ENCUENTRA DICHA VARIABLE)

int main() {
    
    //DEFINO UNA VARIABLE
    int a = 7;
    
    //DEFINO UN PUNTERO A 'a'
    int *aPtr = nullptr; //PUNTERO NULO NO APUNTA A NINGUNA DIRECCION
    cout << aPtr <<" puntero nulo" << endl; //DIRECCION DE MEMORIA
    cout << &a << " direccion de memoria de la variable int a" << endl; //DIRECCION DE MEMORIA
    
    aPtr = &a; // EL PUNTERO APUNTA A LA DIRECCION DE MEMORIA "a"
    cout << aPtr << " PUNTERO CON DIRRECION A LA VARIABLE INT A" << endl; //DIRECCION DE MEMORIA
    cout << *aPtr <<" PUNTERO COMO ENTERO"<< endl; // VALOR DE A COMO VARIABLE = 7
    
    
    
    
    return 0;
}
