//
//  rafaApp.swift
//  rafa
//
//  Created by Juan Cisneros on 5/17/21.
//

import SwiftUI

@main
struct rafaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
