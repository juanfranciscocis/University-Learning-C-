//
//  main.cpp
//  IMPUESTO A LA RENTA ACTUAL
//
//  Created by Juan Cisneros on 5/17/21.
//

#include <iostream>
#include <string>
#include <array>
using namespace::std;

int main() {
    
    array<float, 3> tasa;
    
    cout << "INGRESE EL MONTO NETO DE TASA" << endl;
    cin >> tasa[0];
    
    tasa[1] = tasa[0] + 5;
    tasa[2] = tasa[0] + 10;
    cout << "LOS CALCULOS DE LAS TASAS QUEDARIAN: " << endl;
    for (size_t i = 0; i < tasa.size(); i++) {
        cout << "TASA " << i << ": " << tasa[i] << endl;
    }
    
    float montoUsr, impuestoAPagar = 0.0;
    do {
        cout << "INGRESE EL MONTO DE LA RENTA ACTUAL O 0 PARA SALIR" << endl;
        cin >> montoUsr;
        
        if (montoUsr <= 0) {
            break;
        }else if (montoUsr < 10000){
            cerr << "MONTO NO PUEDE SER MENOR A 10 000" << endl;
            continue;
        }else if (montoUsr >= 10000 and montoUsr <=30000){
            impuestoAPagar = montoUsr * (tasa[0]/100);
        }else if (montoUsr > 30000 and montoUsr <= 60000){
            impuestoAPagar = montoUsr * (tasa[1]/100);
        }else if (montoUsr > 60000){
            impuestoAPagar = montoUsr * (tasa[3]/100);
        }
        
        cout << "IMPUESTO A PAGAR: " << impuestoAPagar << endl;
        
    } while (montoUsr > 0);
    
    return 0;
}
