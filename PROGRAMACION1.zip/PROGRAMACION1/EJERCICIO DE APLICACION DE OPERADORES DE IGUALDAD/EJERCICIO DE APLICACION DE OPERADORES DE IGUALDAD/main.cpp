//
//  main.cpp
//  EJERCICIO DE APLICACION DE OPERADORES DE IGUALDAD
//
//  Created by Juan Cisneros on 3/1/21.
//HOTELES, 3 PRECIOS

#include <iostream>
using namespace::std;

int main() {
    
    
//    VARIABLES DE LOS HOTELES
    int simple = 0;
    int doble = 0;
    int triple = 0;
    int promedio = 0; //VARIABLE DEL PROMEDIO A SER USADA
    
//    INPUT DEL USUARIO
    cout<<"INGRESE UN VALOR PARA HABITACION SIMPLE"<< endl;
    cin >> simple;
    cout<<"INGRESE UN VALOR PARA HABITACION DOBLE"<<endl;
    cin >> doble;
    cout<<"INGRESE UN VALOR PARA HABITACION TRIPLE"<<endl;
    cin >> triple;
//    PROMEDIO
 
    
    promedio = (simple + doble + triple)/3;
    
    cout << "EL PROMEDIO DE BUSQUEDA ES: " << promedio << endl ;
    
    
// ESTRELLAS
    
    if (promedio >= 500) {
        cout << "HOTEL 5 ESTRELLAS"<< endl;
    }else if ( 300 <= promedio && promedio < 500 ){
        cout << "HOTEL 4 ESTRELLAS"<< endl;
    }else{
        cout<<"HOTEL 3 ESTRELLAS"<< endl;
    }
    
   
    int evaluado = 0;
    cout << "Ingrese un numero a ser evaluado";
    cin >> evaluado;
    
    if (evaluado >= 100) {
        cout << "Numero Mayor a 100 o 100";
    }else if (evaluado <= 0){
        cout << "Numero menor a 0 o 0";
        
    }else{
        cout << "El numero evaluado esta entre 0 y 100";
    }
    return 0;
}
