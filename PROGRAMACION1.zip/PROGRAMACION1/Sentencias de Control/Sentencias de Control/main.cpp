//
//  main.cpp
//  Sentencias de Control
//
//  Created by Juan Cisneros on 4/19/21.
//

#include <iostream>
#include <string>
#include <locale>
#include <iomanip>
using namespace std;


int main() {
    //MIENTRAS UN NUMERO SEA MENOR O IGUAL QUE 100 SUMALE 5
/*
    int n =0;
    
    while (n<=100) {
        n+=5;
        cout << n << endl;
    }*/
//Escriba un programa que imprima los multiplos de 7 menores a 1000
    /*int x = 7;
    
    while (x<1000) {
        cout << x << endl;
        x+=7;
    }*/
    
    
//Uso While con contador
    //Una clase 10 estudiantes rinden un test las notas (0 a 100) estan disponibles para ingreso calcule y muestre el total de las notas y el promedio de la clase
  /*  unsigned int counter = 1;
    float nota = 0;
    float total =0 ;
    float promedio = 0;
    
    //INICIALIZAR EL CONTADOR EN 1 Y CONDICION EN 1 MENOR IGUAL A LA CANTIDAD DE VECES A REPETIR
    while (counter <= 10) {
        //INGRESO DE DATO POR EL USUARIO
        cout << "INGRESE UNA NOTA " << counter << ": " <<endl;
        cin >> nota;
        
        //AGREGAR LA NOTA AL TOTAL
        total += nota;
        
        if (counter == 10) {
            promedio = total / 10;
            cout << "PROMEDIO " << promedio << endl;
            cout << "TOTAL: " <<total << endl;
            break;
        }
        
        //ACTUALIZAR EL CONTADOR
        counter+=1;
        
    }
    
   */
    

    
//USO DE WHILE CONTROLADO POR CENTINELA
    
    //CENTINELA: GUARDIA/MILITAR/VIGILA/OBSERVA
    
    //VALOR CENTINELA/SENAL/BANDERA: INDICA QUE EL ULTIMO DATO HA SIDO INGRESADO U OCURRIDO.
    
    //WHILE CONTROLADO POR CENTINELA SE REPITE HASTA QUE EL VALOR CENTINELA OCURRA
    
//Desarrolar un programa para obtner el promedio de una clase que procese notas para un numero arbitrario de estudiantes cada vez que es ejecutado. El ingreso debera terminar cuando el usuario ingrese -1

    int nota = 0;
    int total =0;
    double promedio=0;
    unsigned int contadorDeAlmunos =0;
    
    while (nota>=0){
        cout << "INGRESE LA NOTA O -1 PARA TERMINAR: " << endl;
        cin >> nota;
        
        if (nota <0) {
            break;
            
        }
        total += nota;
        contadorDeAlmunos +=1;
        
    }

    
    if (total > 0 ) {
        promedio = static_cast<double>(total)/contadorDeAlmunos; //STATIC_CAST CAMBIA POR UN SEGUNDO MI VARIABLE A LA QUE YO LE PIDA
        cout << setprecision(10)<<fixed;
        cout << "TOTAL: "<< total <<endl;
        cout << "PROMEDIO: "<< promedio <<endl;
    }else{
        cout << "NO SE INGRESARON NOTAS" << endl;
    }
    

    
    return 0;
}
