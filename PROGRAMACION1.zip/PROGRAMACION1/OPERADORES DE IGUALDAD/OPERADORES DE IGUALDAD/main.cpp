//
//  main.cpp
//  OPERADORES DE IGUALDAD
//
//  Created by Juan Cisneros on 2/24/21.
//USFQ
//PROGRAMA PARA CREAR SENTENCIAS DE IGUALDAD Y RELACIONALES

#include <iostream> //DIRECTIVA DE PREPROCESADOR
using namespace std; //VOY A USAR EL ESPACIO DE NOMBRES STD
using std::cout;
using std::cin;
using std::endl;


int main() {//FUNCION PRINCIPAL
    
//    CIN - COUT - CERR -> std:: -> Obtengo el espacio de nombres std
    
//    if - si
//    Sentencia Condicional, ejecuto acciones en funcion de una condicion
    
    if (2>1) {
        cout << "SI, ES VERDAD!!!!"<< endl;
        
    }
    
// OPERADORES DE IGUALDAD
//    IGUALDAD ==
//    DESIGUALDAD !=

// OPERADORES RELACIONALES
//    RELACIONALES >,< , <= , >=
    
//    ERRORES LOGICOS : OCURREN EN TIEMPO DE EJECUCION
//    SON FATALES O NO FATALES DEPENDIENDO SI TERMINA EL PROGRAMA ABRUCTAMENTE O NO
    
//DECLARACION DE VARIABLES
    
    int a = 0;
    int b = 0;
    
//    INPUT DE VARIABLES POR EL USUARIO
    cout<< "INGRESE DOS NUMEROS ENTEROS PARA DETERMINAR SU RELACION"<<endl;
    cin >> a;
    cin >> b;
    
    if (a==b) { //Igualdad
        cout<< a << " es igual a " << b << endl;
    }
    
    if (a != b) { //Desigualdad
        cout<<  a << " diferente de " << b << endl;
    }
    
    if (a > b) {
        cout << a << " mayor que " << b << endl;
        
    }
    
    if (a < b) {
        cout << a << " menor que " << b << endl;
    }
    
    //SENTENCIA ELSE
        
        if (a > b) {
            cout <<"se ejecuto el if porque a mayor que b" << endl;
    
        }else if (a< b){
            cout << "se ejecuto el else if  por que a no es mayor que b" << endl;
            
        }else{
            cout << "se ejecuto el else por que  a es igual a b " << endl;
        }
    
    
    
    
    
    return 0;
}
