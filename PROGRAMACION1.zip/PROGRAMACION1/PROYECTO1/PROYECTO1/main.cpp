//PROGRAMA QUE IMPRIME TEXTO EN PANTALLA

/* COMENTARIO EN BLOQUE ,
 EN VARIAS
 LINEAS*/

//CREADO POR JUAN FRANCISCO CISNEROS
#include <iostream> //Directiva para entrada y salida de datos (CIN) y la salida (COUT) y (CERR)

//Necesitamos una FUNCION PRINCIPAL
//tipo_de_retorno nombre ()
//{
//    CUERPO DE UNA FUNCION
//}

//TIPOS DE DATOS:
//INT, FLOAT, STRING

int main () //inicia la ejecucion del programa
{
    //Cuerpo de la funcion
    //cout pertenece a un conjunto de nombres std(espacio de nombres del directorio)
    
    std::cout << "Texto en pantalla \n";
    std::cout << "\t Bienvenidos a la \"USFQ\" \n";
    
    
    //los dos puntos dice que cout pertenece a std
    //\n imprime un salto de linea
    // \t imprime una tabulacion antes
    // \es una sentencia de escape
    
    
    
    //toda funcion debe retornar algo, USAMOS UNA SENTENCIA DE RETORNO
    return 0;//El programa termina exitosamente
    
}
 
