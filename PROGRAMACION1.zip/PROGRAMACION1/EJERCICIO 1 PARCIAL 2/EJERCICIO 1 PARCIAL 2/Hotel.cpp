//
//  Hotel.cpp
//  EJERCICIO 1 PARCIAL 2
//
//  Created by Juan Cisneros on 4/20/21.
//

#include <stdio.h>
#include <string>
#include "Hotel.h"
#include <iostream>
using namespace std;


//Constructor

Hotel::Hotel(string name, string city, int stars, float price){
    
    setNombre(name);
    setCiudad(city);
    setEstrellas(stars);
    setPrecio(price);

}

//Set

void Hotel::setNombre(string name){
    if (name.size()<=20){
        nombre =name;
    }else{
        cerr<<"ORIGEN MAXIMO 20 CARACTERES POR LO TANTO SE RECORTA"<<endl;
        nombre=name.substr(0,20);
    }
}

void Hotel::setCiudad(string city){
//    if (city == "Londres") {
//        ciudad = city;
//    } else if (city == "Roma"){
//        ciudad = city;
//    } else if (city == "Paris"){
//        ciudad = city;
//    }else{
//        cerr<< "ERROR DE CIUDAD SE ASIGNA ROMA"<< endl;
//        ciudad = "Roma";
//    }
    
    if (city == "Londres" or city == "Roma" or city == "Paris") {
        ciudad = city;
    }else{
        cerr<< "ERROR DE CIUDAD SE ASIGNA ROMA" <<endl;
        ciudad = "Roma";
    }
    
    
}

void Hotel::setEstrellas(int stars){
    if(stars > 5 || stars < 0){
        cerr << "ERROR DE ESTRELLAS SE ASIGNAN 3"<< endl;
        estrellas = 3;
    }else{
        estrellas = stars;
    }
}


void Hotel::setPrecio(float price){
    if (price <=0){
        cerr << "PRECIO ES MENOR O IGUAL A CERO SE ASIGNA 100$"<<endl;
        precio = 100;
    }else{
        precio = price;
    }
}
//Get
string Hotel::getNombre()const{
    return nombre;
}

string Hotel::getCiudad()const{
    return ciudad;
}

int Hotel::getEstrellas()const{
    return estrellas;
}

float Hotel::getPrecio()const{
    return precio;
}


//Datos

void Hotel::datosHotel()const{
    cout << "NOMBRE " << getNombre()<< endl;
    cout <<"CUIDAD " <<getCiudad()<< endl;
    cout <<"ESTRELLAS " <<getEstrellas()<< endl;
    cout <<"PRECIO " <<getPrecio()<< endl;
}





