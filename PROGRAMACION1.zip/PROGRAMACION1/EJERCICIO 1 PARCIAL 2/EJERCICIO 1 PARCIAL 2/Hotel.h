//
//  Hotel.h
//  EJERCICIO 1 PARCIAL 2
//
//  Created by Juan Cisneros on 4/20/21.
//
#include <string>
class Hotel{
public:
    Hotel (std::string, std::string, int, float);
    
    
    void setNombre (std::string);
    void setCiudad (std::string);
    void setEstrellas (int);
    void setPrecio (float);
    
    std::string getNombre()const;
    std::string getCiudad()const;
    int getEstrellas()const;
    float getPrecio()const;
    
    
    void datosHotel ()const;
    
private:
    std::string nombre;
    std::string ciudad;
    int estrellas;
    float precio;
    
    
    
    
    
    
    
    
};

