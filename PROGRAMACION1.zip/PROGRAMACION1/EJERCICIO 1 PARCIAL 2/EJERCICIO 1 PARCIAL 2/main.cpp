//
//  main.cpp
//  EJERCICIO 1 PARCIAL 2
//
//  Created by Juan Cisneros on 4/20/21.
//

#include <iostream>
#include "Hotel.h"
#include <string>
using namespace std;

int main() {
    
    Hotel hotel1("JUAN FRANCISCO CISNE","Londres", 2,1000 );
    
    hotel1.datosHotel();
    
    
    
    return 0;
}
