//
//  Viaje.cpp
//  ADMINISTRARunVIAJE
//
//  Created by Juan Cisneros on 5/15/21.
//

#include "Viaje.h"
#include <string>
#include <iostream>
using namespace::std;

Viaje::Viaje(string origin, string end, string arrival, string type, int date, int month, int year, int bus, int price ){
    
    setOrigen(origin);
    setDestino(end);
    setTrayecto(arrival);
    setClase(type);
    setFecha(date, month, year);
    setBus(bus);
    setPrecio(price);
}


void Viaje::setOrigen(string origin){
    
    while (origin != "GYE" and origin != "UIO" and origin != "CUE" ) {
        cerr << "REINGRESE EL ORIGEN" << endl;
        getline(cin,origin);
    }
    
    origen = origin;
}

string Viaje::getOrigen()const{
    return origen;
}

void Viaje::setDestino(string end){
    while ((end != "GYE" and end != "UIO" and end != "CUE") or end == getOrigen() ) {
        cerr << "REINGRESE EL DESTINO" << endl;
        getline(cin,end);
    }
    
    destino =  end;
}

string Viaje::getDestino()const{
    return destino;
}

void Viaje::setTrayecto(string arrival){
    while (arrival != "Ida" and arrival != "Ida/Vuelta") {
        cerr << "REINGRESE EL TRAYECTO" << endl;
        getline(cin,arrival);
    
    }
    
    trayecto = arrival;
}

string Viaje::getTrayecto()const{
    return trayecto;
}

void Viaje::setClase(string type ){
    while (type != "Business" and type != "Economica") {
        cerr << "REINGRESE LA CLASE" << endl;
        getline(cin,type);
    
    }
    
    clase = type;
}

string Viaje::getClase()const{
    return clase;
}

void Viaje::setFecha(int date, int month, int year){
    while (date <= 0 or date >31){
        cerr << "REINGRESE EL DIA" << endl;
        cin >> date;
    }
        
    while (month <= 0 or month > 12) {
        cerr << "REINGRESE EL MES" << endl;
        cin >> month;
    }
        
    while (year < 2021) {
        cerr << "REINGRESE EL ANO" << endl;
        cin >> year;
    }
    
    if (date < 15 and month <= 5 and year <=2021) {
        cerr << "ERROR DE FECHA MENOR 1" << endl;
        setFecha(0, 0, 0);
        
    }else if (date >=15 and month < 5 and year <=2021) {
        cerr << "ERROR DE FECHA MENOR 2" << endl;
        setFecha(0, 0, 0);
        
    } else{
        dia = date;
        mes = month;
        ano = year;
    }
    
    
    
}

int Viaje::getDia()const{
    return dia;
}
    
int Viaje::getMes()const{
    return mes;
}

int Viaje::getAno()const{
    return ano;
}
    
void Viaje::setBus(int bus){
    
    while (bus < 1 or bus > 40) {
        cerr << "REINGRESE LINEA DEL BUS" << endl;
        cin >>  bus;
        
    }
    
    numeroDeAutoBus = bus;
}

int Viaje::getBus()const{
    return numeroDeAutoBus;
}

void Viaje::setPrecio(int price){
    
    while (price <= 0 or price%5 != 0) {
        cerr << "REINGRESE EL PRECIO" << endl;
        cin >> price;
    }
    
    precio = price;
    
}

int Viaje::getPrecio()const{
    return precio;
}
    
    


void Viaje::datosViaje()const{
    cout << "---DATOS VIAJE ---" << endl;
    cout << "SALIDA DEL AREOPUERTO: " <<getOrigen()<< endl;
    cout << "CON DESTINO A: " <<getDestino()<< endl;
    cout << "NUMERO DE VOLETOS ELECTOS: "<<getTrayecto()<< endl;
    cout << "USTED VOLARA EN CLASE: " <<getClase() << endl;
    cout << "FECHA DE REGRESO: " <<getDia()<<" / "<< getMes() <<" / "<< getAno() << endl;
    cout <<"LINEA DEL BUS: " <<getBus() << endl;
    cout << "PRECIO ASIGNADO: $" << getPrecio() << endl;

    
    
}
