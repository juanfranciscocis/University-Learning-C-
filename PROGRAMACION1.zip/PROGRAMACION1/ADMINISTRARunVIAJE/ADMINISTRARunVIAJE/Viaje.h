//
//  Viaje.h
//  ADMINISTRARunVIAJE
//
//  Created by Juan Cisneros on 5/15/21.
//

#include <string>


class Viaje{
    
public:

    Viaje(std::string,std::string,std::string,std::string,int,int,int,int,int);
    
    void setOrigen(std::string);
    void setDestino(std::string);
    void setTrayecto(std::string);
    void setClase(std::string);
    void setFecha(int,int,int);
    void setBus(int);
    void setPrecio(int);
    
    
    std::string getOrigen()const;
    std::string getDestino()const;
    std::string getTrayecto()const;
    std::string getClase()const;
    int getBus() const;
    int getPrecio()const;
    int getAno()const;
    int getDia()const;
    int getMes()const;
    
    void datosViaje ()const;
    
    
    
    
private:
    std::string origen, destino, trayecto, clase;
    int fecha, ano, dia, mes, numeroDeAutoBus, precio;
    
    
    
    
    
    
    
    
};
