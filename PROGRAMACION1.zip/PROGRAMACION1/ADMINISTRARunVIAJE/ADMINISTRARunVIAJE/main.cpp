//
//  main.cpp
//  ADMINISTRARunVIAJE
//
//  Created by Juan Cisneros on 5/15/21.
//

#include <iostream>
#include <stdio.h>
#include "Viaje.h"
#include <string>
#include <iostream>
using namespace::std;


int main() {
    
    for (int i = 0; i <5; i++) {
        Viaje viaje1 ("", "", "", "", 0,0,0,0,0);
        viaje1.datosViaje();
        cin.ignore();
    }
    
    
    
    return 0;
}



