//
//  Auto.cpp
//  DEBER2
//
//  Created by /Users/juancisneros/Documents/C++/PROGRAMACION1/DEBER2/DEBER2/Auto.cppJuan Cisneros on 5/4/21.
//
//Directivas
#include <stdio.h>
#include "Auto.h"
#include <string>
#include <iostream>
using namespace std;


//Constructor para la clase Auto

Auto::Auto(string marca, string modelo, float precio){
    //Validacion del constructor
    setMarca(marca);
    setModelo(modelo);
    setPrecio(precio);
    
}

//Funciones set

void Auto::setMarca(string brand){
    
    while (brand != "Toyota" and brand != "VW" and brand != "Ford") { //Loop infinito hasta que la marca asignada concuerde
        cout << "ERROR EN LA MARCA ASIGNADA FAVOR VOLVER A INGRESAR:"<< endl;//Se informa al usuario de que la marca no es la correcta
        getline(cin,brand);//Ingreso de nueva marca

        
    }
    
    marca = brand; //Solo si la marca ingresada es correcta se asigna al dato miembro marca.
    
    
}

void Auto::setModelo(string model){
    while (model.size() > 20) { //Se chequea que el modelo ingresado tenga menos de 20 caracteres
        cout << "EL MODELO INGRESADO ES DEMASIADO LARGO FAVOR REINGRESAR" << endl;//Si el modelo asignado es mas de 20 caracteres se informa al usuario
        getline(cin, model);//Se pide el reingreso del dato
    }
    
    modelo = model; //Si el modelo ingresado tiene menos de 20 caracteres se lo asigna al dato miembro modelo.

    
}

void Auto::setPrecio(float price){
    while (price < 15000) { //Se chequea que el precio sea mayor o igual a 1500$
        cout << "EL PRECIO AIGNADO ES MUY BAJO FAVOR REINGRESARLO: "<< endl;// En caso de no ser mayor a 1500 se informa al usuario
        cin >> price; //Se pide el reingreso del precio
    }
    
    precio = price; //En caso de que el precio sea mayor o igual a 1500$ se asigna este al dato miembro precio
    

}





//Funciones get

string Auto::getMarca()const{ //se obtiene la marca
    return marca;
}

string Auto::getModelo()const{ //se obtiene el modelo
    return modelo;
}

float Auto::getPrecio()const{ // se obtiene el precio
    return precio;
}






void Auto::infoAuto()const{ //Se muestran los datos ingresados de los objetos
    cout <<endl;
    cout <<"----- INFORMACION DEL AUTO -----" << endl;
    cout <<"LA MARCA ASIGNADA ES: "<<getMarca() << endl;
    cout <<"EL MODELO DE AUTOMOVIL ASIGNADO ES: " <<getModelo() << endl;
    cout <<"EL PRECIO ASIGNADO ES: " <<getPrecio()<<"$" << endl;
}
