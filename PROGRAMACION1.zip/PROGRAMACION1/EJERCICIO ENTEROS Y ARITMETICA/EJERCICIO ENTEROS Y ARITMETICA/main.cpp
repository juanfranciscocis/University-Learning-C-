//
//  main.cpp
//  EJERCICIO ENTEROS Y ARITMETICA
//
//  Created by Juan Cisneros on 2/22/21.
//
//PROGRAMA QUE OBTIENE UN MODULO, UNA MULTIPLICACION Y FINALMENTE UNA DIVISION ENTRE LA MULTIPLICACION Y DIVISION
#include <iostream>

int main() {
    
    
    //    DECLARO VARIABLES
        int numero1;//GUARDO ENTEROS
        int numero2;//GUARDO ENTEROS
        int numero3;//GUARDO ENTEROS
        int numero4;//GUARDO ENTEROS
        int producto; //MULTIPLICO NUMERO1,2 Y 3
        int modulo; //GUARDO MODULO ENTRE NUMERO2 Y NUMERO4
        int div_Mod_Prod; // GUARDO LA DIVISION DEL PRODUCTO Y MODULO
  
    //    INPUT DE VARIABLES
        std::cout <<"INGRESE UN NUMERO ENTERO"<<std::endl;
        std::cin >> numero1;
        std::cout <<"INGRESE UN NUMERO ENTERO"<<std::endl;
        std::cin >> numero2;
        std::cout <<"INGRESE UN NUMERO ENTERO"<<std::endl;
        std::cin >> numero3;
        
    //PRODUCTO DE LOS TRES NUMEROS
        
        producto = numero1 * numero2 * numero3;
        
    //INPUT DE LA ULTIMA VARIBALE
        
        std::cout << "INGRESE UN ULTIMO NUMERO ENTERO" << std::endl;
        std::cin >> numero4;
        
    //MODULO ENTRE EL SEGUNDO Y CUARTO NUMERO
        
        modulo = numero2 % numero4;
      
        
    //DIVISION DEL PRODUCTO Y MODULOS
        
        div_Mod_Prod = producto / modulo;
        
    //IMPRIMO
        
        std::cout << "PRODUCTOS = " << producto << std::endl;
        std::cout<<"MODULO = " <<modulo<< std::endl;
        std::cout<< "DIVISION ENTRE PRODUCTO Y MODULOS ANTERIORES = " << div_Mod_Prod << std::endl;
        
        


    
    
    
    return 0;
}
