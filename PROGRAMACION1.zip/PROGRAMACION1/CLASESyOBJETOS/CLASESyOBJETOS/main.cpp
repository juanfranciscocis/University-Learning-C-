//
//  main.cpp
//  CLASESyOBJETOS
//
//  Created by Juan Cisneros on 3/15/21.
// Programa que define la clase Smartphone

#include <iostream>
using namespace::std;



//Definicion de la clase Smartphone
class Smartphone {
    
    // Especificador de Acceso (Quien puede o no modificar), Controlo quien accede a mi informacion
    
    public: //Todo lo definido, se puede utilizar por funciones fuera de la clase. Por ejemplo main()
//        Funciones miembro (o comportaminetos) deberian ser publicas
//        Los Datos miembro ( caracteristicas/atributos) seran privados
    
//    Funcion que imprime texto en pantalla
    
        void mostrarMensaje(string model) const{ //Funcion que no retorna nada y CONST indica que la funcion no modifica el objeto
            
            cout << "mensaje desde smartphone "<< model << endl;// Muestra el mensaje en pantalla
            

    
        }
    
    
    
    //*** FUNCIONES SET Y GET ***
    //SET = ASIGNAR
    //GET = OBTENER
    //TODO DATO MIEMBRO REQUIERE UNAS FUNCIONES SET Y GET
    
    void setMarca (string brand){ //Ninguna funcion set es const
        marca = brand; //Se asigna el valor del parametro al dato miembro.
    }
   
    
    
    //FUNCIONES GET -> obtener valor del dato miembro
    string getMarca() const { //Toda funcion get debe ser const
        return marca;
    }
    
    
    
    private: //Datos miembro solo pueden ser usados por funciones de esta clase!.
    
    //Variables del tipo local = Solo pueden ser utilizadas dentro de la clase
        string marca; //Marca del Smartphone
        string modelo; //Modelo del Smartphone
    
    //FUNCIONES SET -> ASIGNAR VALOR A UN DATO MIEMBRO (VOID)
    
    
    
    
    
        
    
    
    
    
    

};


// Funcion principal
int main(){
    
    // Creacion de un objeto de la clase Samrtphone
    Smartphone sp1; //Nombre de la clase y luego un nombre para el objeto
    
    
    
  
    
    cout << "INGRESE EL MODELO DE SMARTPHONE: ";
    string modelo; //Tipo de dato para almacenar cadenas de caracteres
    getline(cin,modelo); //Obtener una cadena de caracteres
    
    //Uso o llamada a la funcion mensaje
    sp1.mostrarMensaje(modelo);//Nombre del objeto + . + nombre de la funcion + () + ;
    
    
    


    
    return 0;
}

