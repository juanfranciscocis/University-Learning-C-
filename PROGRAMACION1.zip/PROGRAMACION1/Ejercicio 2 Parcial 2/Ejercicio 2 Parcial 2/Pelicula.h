//
//  Pelicula.h
//  Ejercicio 2 Parcial 2
//
//  Created by Juan Cisneros on 4/20/21.
//

#include <string>

class Pelicula{
public:
    
    Pelicula (std::string,int ,float, int);
    
    //Set
    void setNombre(std::string);
    void setPublicacion(int);
    void setPrecio(int);
    void setHD(float);
    
    //Get
    
    std::string getNombre()const;
    int getPublicacion()const;
    int getPrecio()const;
    float getHD()const;
    
    
    void datosPelicula()const;
    
    
    
    
    
    
private:
    std::string nombre;
    int publicacion;
    int precio;
    float hd;
    
    
    
    
    
    
    
    
    
    
};
