//
//  main.cpp
//  Ejercicio 2 Parcial 2
//
//  Created by Juan Cisneros on 4/20/21.
//

#include <iostream>
#include <string>
#include "Pelicula.h"
using namespace std;





int main() {
    string nombre;
    int publicacion,hd,precio,contador;
    
    
    
    
    //Creo dos objetos de la clase pelicula
    Pelicula pelicula1("",2010,1,0), pelicula2("",2010,1,0);

    
    
    
    contador =0;
    while (contador!=2) {
        if (contador == 0) {
            
            //obtengo datos del usuario
            
            cout << "NOMBRE" << endl;
            getline(cin,nombre);
            cout <<"ANO ESTRENO" <<endl;
            cin >> publicacion;
            cout<<"ALMACENAMIENTO" <<endl;
            cin >> hd;
            cout << "PRECIO DE LA PELICULA" <<endl;
            cin >>precio;
            
            pelicula1.setNombre(nombre);
            pelicula1.setPublicacion(publicacion);
            pelicula1.setHD(hd);
            pelicula1.setPrecio(precio);
            pelicula1.datosPelicula();
            contador +=1;
            continue;
            
        }else if(contador ==1){
            cin.ignore();
            cout << "NOMBRE" << endl;
            getline(cin,nombre);
            cout <<"ANO ESTRENO" <<endl;
            cin >> publicacion;
            cout<<"ALMACENAMIENTO" <<endl;
            cin >> hd;
            cout << "PRECIO DE LA PELICULA" <<endl;
            cin >>precio;
            
            pelicula2.setNombre(nombre);
            pelicula2.setPublicacion(publicacion);
            pelicula2.setHD(hd);
            pelicula2.setPrecio(precio);
            pelicula2.datosPelicula();
            contador +=1;
            continue;
        }else{
            contador+=1;
        }
        
        
        
    }
    

    
    

    return 0;
}
