//
//  Pelicula.cpp
//  Ejercicio 2 Parcial 2
//
//  Created by Juan Cisneros on 4/20/21.
//

#include <stdio.h>
#include <string>
#include <iostream>
#include "Pelicula.h"
using namespace std;

Pelicula::Pelicula (string movie, int year, float hardDrive, int price){
    setNombre(movie);
    setPublicacion(year);
    setHD(hardDrive);
    setPrecio(price);
    
    
}


//SET
void Pelicula::setNombre(string name){
    
    if (name.size()>40) {
        
        cerr<< "Pasado el numero de caracteres"<<endl;
        
        nombre = name.substr(0,40);
        
    }else{
        nombre = name;
    }

}

void Pelicula::setPublicacion(int year){
    
    if (year < 2010 || year > 2021 ) {
        publicacion = 0;
        cerr<< "NO SE PUEDE ASIGNAR LA FECHA"<<endl;
    }else{
        publicacion = year;
    }
    
    
}

void Pelicula::setHD(float hardDrive){
    if (hardDrive < 1) {
        cerr << "NO SE PUEDE ASIGNAR MENOR A UNA GB"<<endl;
        hd = 1;
    }else{
        hd = hardDrive;
    }
    
}

void Pelicula::setPrecio(int price){
    if (price <0 || price%2 !=0){
        cerr<<"PRECIO MENOR A CERO O NO PAR"<<endl;
        precio = 0;
    }else{
        precio = price;
    }
    
}

//Get

string Pelicula::getNombre()const{
    return nombre;
}

int Pelicula::getPublicacion()const{
    return publicacion;
}

float Pelicula::getHD()const{
    return hd;
}

int Pelicula::getPrecio()const{
    return precio;
}

//Datos

void Pelicula::datosPelicula()const{
    cout<<"Nombre: " << getNombre()<<endl;
    cout<<"Publicacion " << getPublicacion()<<endl;
    cout<<"Almacenamiento " <<getHD()<<endl;
    cout<<"Precio " << getPrecio()<<endl;
}






