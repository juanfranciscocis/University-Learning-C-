//
//  main.cpp
//  FOR EJERCICIOS
//
//  Created by Juan Cisneros on 5/15/21.
//

#include <iostream>
using namespace::std;

int main() {
    
    //Escribir un programa que sume una cantidad ingresada de enteros por el usuario usando un lazo for
    
    /*
    int cantidadDeEnteros, enterosUsr, total = 0;
    cout << "INGRESE LA CANTIDAD DE ENTEROS QUE QUIERE SUMAR" << endl;
    cin >> cantidadDeEnteros;
    
    for (int i=0 ; i < cantidadDeEnteros; i++) {
        cout << "INGRESE UN ENTERO A SUMAR" << endl;
        cin >> enterosUsr;
        
        total += enterosUsr;

        
        
    }
    
    cout << "Total " << total << endl;
    
    */
    
    /*
    int ingresoIntUsr, numeroDeDatosUsr, menorNumero = 0;
    
    cout << "INGRESE NUMERO DE DATOS" << endl;
    cin >> numeroDeDatosUsr;
    
    
    
    
    
    for (int i = 0; i < numeroDeDatosUsr; i++) {
        cout << "INGRESE UN NUMERO PORFAVOR" << endl;
        cin >> ingresoIntUsr;
        if (i ==0) {
            menorNumero = ingresoIntUsr;
        }
        
        
        if (ingresoIntUsr <= menorNumero) {
            menorNumero = ingresoIntUsr;
        }
    }
    
    cout << menorNumero << endl;
    */
    
    
    
    
    //ESCRIBIR UN LAZO FOR QUE CALCULE EL PRODUCTO DE LOS PRIMEROS 15 NUMEROS IMPARES
    int total =1;
    for (int i = 0; i<= 15; i++) {
        if (i%2 != 0) {
            total *= i;
        }
    }
    
    cout << total << endl;
    
    
    
    
    return 0;
}
