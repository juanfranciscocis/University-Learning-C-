//
//  main.cpp
//  EJERICIO TEXTO EN PANTALLA
//
//  Created by Juan Cisneros on 2/10/21.
//

#include <iostream>


int main(){
    
    std::cout << "Universidad\n";
    std::cout <<"\tSan Francisco \n";
    std::cout << "\t \tde quito\n";
    std::cout << "\n";
    std::cout << " * * * * * \n";
    
    std::cout << "\nEN UNA LINEA!!!\n";
    
    std::cout << "\nUniversidad\n\tSan Francisco \n\t \tde quito\n\n* * * * * \n";
    
    return 0;
    
}
