//
//  main.cpp
//  ARRAY
//
//  Created by Juan Cisneros on 5/10/21.
//



#include <iostream>
using namespace std;
//LIBRERIA ARRAY
#include <array>



int main() {
    
    //Definicion de arreglos // ARRRAY < TIPO DE VAR , MAX TAMANO > NOMBRE DE LA VARIABLE;
    array< int ,7> a = {3,5,9}; //PUEDO O NO ESPECIFICAR VALORES PREDETERMINADOS
    
    // IMPRIMO ARRGLOS ACCEDIENDO VALORES DEL ARREGLO
    cout <<  "IMPRIMO UN ELEMENTO: " << a[6] << endl;
    
    for (size_t i=0; i<a.size(); i++) {
        cout << a[i] << endl;
    }
    
    // ARREGLO DE OBJETOS
    //array<nombre de la clase, max objetos> nombre del arreglo;
    
    //ARREGLO MULTIDIMENSIONAL
    
    array<array<int, 3>, 2> arregloDelArreglo; //Tres columnas con 2 filas
    
    arregloDelArreglo = {1,2,3,4,5,6};
    
    for (size_t i=0; i<2; i++) {
        for (size_t c =0; c<3; c++) {
            cout << arregloDelArreglo[i][c]<< endl;
        }
    }
    
    
    
    
    
    return 0;
}
