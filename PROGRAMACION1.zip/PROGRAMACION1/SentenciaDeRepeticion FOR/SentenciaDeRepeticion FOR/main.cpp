//
//  main.cpp
//  SentenciaDeRepeticion FOR
//
//  Created by Juan Cisneros on 5/3/21.
//

#include <iostream>
using namespace::std;
int main() {
    
    
    //FOR : SENTENCIA DE REPETICION
    
    //MAS ABREVIADO QUE UN WHILE
    //SE UTILIZA CUANDO LA CANTIDAD DE REPETICIONES ES CONOCIDA, REPETICION POR CONTADOR
    //NO PUEDO UTILIZARLO CUANDO ES INDEFINIDO, REPETICIONES CONTROLADAS POR CENTINELA
    
    //SINTAXIS
    
    //for(definicion e inicializacion de var.control ; condicion del lazo, incremento//decremento de la var.control)
    
    /*
    for (int i=1; i<=10 ; i++) {
        cout << i << endl;
    }
    
    //con while
    
    int num =1;
    while (num <=10) {
        cout << num <<endl;
        num++;
    }
    */
    
    
    int cant = 0;
    int num;
    cout << "INGRESE UNA CANTIDAD DE NUMEROS ENTEROS" <<endl;
    cin >> cant;
    
    int producto = 1;
    
    for (int i = 1; i<=cant; i++) {
        
        //INGRESO DE NUMERO
        cout << "ingrese numero" << endl;
        cin >> num;
        
        producto *= num;
      
        
        
        
    }
    
    
    cout << producto << endl;
    
    
    
    
    
    
    
    
    
    
    
    return 0;
}
