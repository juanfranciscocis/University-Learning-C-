//
//  main.cpp
//  EJERCICIO DE CLASES, OBJETOS, SET, GET, CONSTRUCTORES
//
//  Created by Juan Cisneros on 4/5/21.
//

#include <iostream>
#include <string>
using namespace :: std;


class Libro{
public:
    
    Libro (string title, string author, int year) :titulo(title), autor(author), anio(year){
        //CONSTRUCTOR PARA LIBRO
    }
    
    void setTitulo (string title){
        titulo = title;
    }
    
    void setAutor(string author){
        autor = author;
        
    }
    
    void setAnio (int year){
        anio =year;
    }
    
    string getTitulo(){
        return titulo;
    }
    
    string getAutor(){
        return autor;
    }
    
    int getAnio(){
        return anio;
    }
    
    void datosLibro(){
        cout << "LIBRO: " << titulo<< endl;
        cout << "AUTOR: "<< autor<<endl;
        cout << "ANO: " << anio<<endl;
    }
    
    
    
    
    
    
    
private:

    //DEFINO DATOS MIEMBRO
    string titulo;
    string autor;
    int anio;
    
    
    
};





int main() {
    
    Libro book("PROGRAMACION 1 ","JUAN FRANCISCO CISNEROS",2021);
    book.datosLibro();

    
    
    
    
    
    
    
    
    
    return 0;
}
