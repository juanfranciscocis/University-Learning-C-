//
//  Smartphone.cpp
// IMPLEMENTACION DE LA CLASE

#include <iostream> //COUT Y CIN
#include <string> //CADENAS STRING
#include "Smartphone.h" //INTERFAZ DE CLASE SMARTPHONE //COMILLAS DOBLES BUSCA DENTRO DE LOS ARCHIVOS DEL PROYECTO // <...>, BUSCA DENTRO DE LA DIRECTIVA DE C++
using namespace::std; //ESPACIO DE NOMBRES STD


//IMPLEMENTACION DE LAS FUNCIONES MIEMBRO

//CONSTRUCTOR //Nombre de la clase + dos puntos + constructor

Smartphone::Smartphone (string brand, string model , float price) //: marca(brand), modelo(model), precio(price)
{
    
//ASIGNO Y VALIDO DATOS MIEMBRO CON LAS FUNCIONES SET
    setMarca(brand);
    setModelo(model);
    setPrecio(price);
    
    
}

// FUNCIONES SET Y GET

//SET
void Smartphone::setMarca(string brand){
    //marca = brand;
    
    //VALIDACION DE DATOS!!!
    //LA LONGITUD DE LA CADENA NO SEA MAYOR A 15 CARACTERES, SI SE DA EL CASO SE MUESTRA UN MENSAJE AL USUARIO Y SE LE SOLICITA UNA VEZ MAS
    
    if (brand.size()<=15) {
        marca = brand; //asigno el parametro del dato miembro
    }else{
        cerr<<"ERROR CADENA DE CARACTERES MAYOR A 15"<< endl;
        
        getline(cin,marca);//ASIGNO EL CIN A MARCA
        
        
        
        
    }
    
}


void Smartphone::setModelo(string model){
    //modelo =model;
    //VALIDACION DE DATOS!!!
    //LA LONGITUD DE LA CADENA NO SEA MAYOR A 20 CARACTERES, SI SE DA EL CASO SE MUESTRA UN MENSAJE AL USUARIO Y SE RECORTA LA CADENA A 20
    
    if (model.size()<=20) {
        modelo = model; //asigno el parametro del dato miembro
    }else{
        cerr<<"ERROR CADENA DE CARACTERES MAYOR A 2O"<< endl;
       modelo = model.substr(0,20);//PRIMER ARGUMENTO ES DONDE COMIENZA, EL ULTIMO ES LA CANTIDAD DE ELEMENTOS.
    }
    
    
    
    
    
    
}

void Smartphone::setPrecio(float price){
    // precio =price;
    //VALIDACION DE DATOS!!!
    //SE ASIGNARA EL PRECIO SOLAMENTE SI EL VALOR ES > A 100, CASO CONTRARIO SE MOSTRARA UN MENSAJE DE ERROR Y SE ASIGNARA POR DEFECTO 100$
    
    if (price >= 100){
        
        precio = price; //SE ASIGNA AL DATO MIEMBRO
        
        
    }else{
        cerr<<"PRECIO INVALIDO. DEBE SER AL MENOS 100, SE ASIGNA POR DEFECTO 100"<<endl;
        precio = 100; //ASIGNO POR DEFECTO 100 AL DATO MIEMBRO
        
        
    }
    
    
}

//GET
string Smartphone::getMarca()const{
    return marca;
}

string Smartphone::getModelo()const{
    return modelo;
}

float Smartphone::getPrecio()const{
    return precio;
}


//Funcion datosSmartphone

void Smartphone::datosSmartphone()const{
    cout << "MARCA: " << getMarca()<<endl;
    cout <<"MODELO: " << getModelo()<<endl;
    cout <<"PRECIO: " <<getPrecio()<<endl;
}






