//
//  main.cpp
// USO DE LA CLASE SMARTPHONE
#include <iostream> //COUT Y CIN
#include <string> //CADENAS STRING
#include "Smartphone.h" //INTERFAZ DE CLASE SMARTPHONE //COMILLAS DOBLES BUSCA DENTRO DE LOS ARCHIVOS DEL PROYECTO // <...>, BUSCA DENTRO DE LA DIRECTIVA DE C++
using namespace::std; //ESPACIO DE NOMBRES STD

int main() {
    //DEFINO VARIABLES
    string marcaUsuario, modeloUsuario;
    float precioUsuario = 0 ;
    
    
    // CREACION DEL OBJETO CON EL CONSTRUCTOR
    
    Smartphone sp1 ("","",100);
    
    //Mostrar datos smartphone
    sp1.datosSmartphone();
    
    //SOLICITAR DATOS AL USUARIO
    
    cout << "INGRESE LA MARCA" << endl;
    
    getline(cin, marcaUsuario);
    
    sp1.setMarca(marcaUsuario);//ASIGNAMOS EL VALOR DEL USUARIO AL DATO MIEMBRO DE MI CLASE Smartphone, CON  LA VALIDACION RESPECTIVA.
    
    
    //SOLICITAR DATOS AL USUARIO
    
    cout << "INGRESE LA MODELO" << endl;
    
    getline(cin, modeloUsuario);
    
    sp1.setModelo(modeloUsuario);//ASIGNAMOS EL VALOR DEL USUARIO AL DATO MIEMBRO DE MI CLASE Smartphone, CON  LA VALIDACION RESPECTIVA.
    

    
    //SOLICITAR DATOS AL USUARIO
    
    cout << "INGRESE PRECIO" << endl;
    
    cin >> precioUsuario;
    
    sp1.setPrecio(precioUsuario);//ASIGNAMOS EL VALOR DEL USUARIO AL DATO MIEMBRO DE MI CLASE Smartphone, CON  LA VALIDACION RESPECTIVA.
    
    
    //MUESTRO LOS VALORES!!!
    sp1.datosSmartphone();
    
    
    

    
    
    
    
    return 0;
}
