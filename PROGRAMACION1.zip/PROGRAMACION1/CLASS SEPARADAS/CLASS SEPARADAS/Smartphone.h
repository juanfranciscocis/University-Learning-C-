//
//  Smartphone.h
//INTERFAZ DE LA CLASE
#include <string> //Cadena de caracteres

class Smartphone {
    
private:
    
    //DATOS MIEMBRO
    
    std:: string marca;
    std:: string modelo;
    float precio;
    
    
    
    
public:
    //PROTOTIPOS DE FUNCIONES
    
    Smartphone (std::string, std::string, float);//Constructor
    
    //Funciones SET y GET
    
    void setMarca(std::string);
    std::string getMarca () const;
    
    void setModelo (std::string);
    std::string getModelo () const;
    
    void setPrecio (float);
    float getPrecio() const;
    
    //Funcion Datos Smartphone
    
    void datosSmartphone () const;
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
};
