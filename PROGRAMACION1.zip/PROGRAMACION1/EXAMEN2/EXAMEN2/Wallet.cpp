//
//  Wallet.cpp
//  EXAMEN2
//
//  Created by Juan Cisneros on 4/21/21.
//

#include <string>
#include <iostream>
#include "Wallet.h"
using namespace std;

Wallet::Wallet(string user, long int iD, float balance){
    setTitular(user);
    setCedula(iD);
    setSaldo(balance);
    
    
}

//Set y Get

void Wallet::setTitular(string user){
    
    if(user.size()<=30){
        titular = user;
    }
        
    if (user.size()>30){
        cerr << "NOMBRE DE TITULAR MAYOR A 30 CARACTERES REINGRESARLOS: "<<endl;
        getline(cin,user);
        if (user.size()>30) {
            cerr << "NOMBRE DEL TITULAR MAYOR A 30 CARACTERES SE RECORTAN"<<endl;
            titular = user.substr(0,30);
        }else{
            titular = user;
        }
    }
    
}

void Wallet::setCedula(long int iD){
 
    if (iD/ 100000000 < 1 or iD / 100000000 > 24) {
        cerr << "ERROR DE INGRESO DE CEDULA, REINGRESE" << endl;
        cin >> iD;
        if (iD/ 100000000 < 1 or iD / 100000000 > 24) {
            cerr << "ERROR DE INGRESO DE CEDULA, ASIGNO 0" << endl;
            cedula = 0;
        }else{
            cedula = iD;
        }
    }else {
        cedula = iD;
    }
    
    
}

void Wallet::setSaldo(float balance){
    if (balance < 0) {
        cerr<<"NO SE PUEDE ASIGNAR VALORES MENORES A 0 EN EL SALDO SE ASIGNA 0"<<endl;
        saldo = 0;
    }else{
        saldo = balance;
    }
}

string Wallet::getTitular()const{
    return titular;
}

long int Wallet::getCedula()const{
    return cedula;
}

float Wallet::getSaldo()const{
    return saldo;
}




//Balance Wallet

void Wallet::balanceWallet()const{
    cout << "" << endl;
    cout <<"--Wallet Balance--"<<endl;
    cout << "Titular: "<<getTitular() <<endl;
    cout << "Cedula: "<<getCedula() << endl;
    cout << "Saldo: " << getSaldo()<< endl;
    cout << "" << endl;
    
}

//Recargar Wallet

void Wallet::recargarWallet(float recharge){
    if(recharge > 5000 or recharge <0){
        cerr << "RECARGA NO PROCESADA" <<endl;
    }else{
        cout << "RECARGA EXITOSA" <<endl;
        setSaldo(getSaldo()+recharge);
    }
}

//Pagar con Wallet

void Wallet::pagarWaller(float pay){
    if (pay < 0) {
        cerr << "VALOR NEGATIVO DE PAGO" <<endl;
    }else{
        if (getSaldo() < pay) {
            cerr << "PAGO INSUFICIENTE" <<endl;
            
        }else{
            cout << "PAGO EXITOSO" << endl;
            setSaldo(getSaldo()-pay);
        }
        
    }
}

void Wallet::transferirMontoWallet(long int iD , float pay){
    
    if (iD/ 100000000 < 0 or iD / 100000000 > 24) {
        cerr << "ERROR DE INGRESO DE CEDULA, REINGRESE" << endl;
        cin >> iD;
        if (iD/ 100000000 < 0 or iD / 100000000 > 24) {
            cerr << "ERROR DE INGRESO DE CEDULA" << endl;
            iD = 0;
            pay = -1000;
        }else{
            cout << "CEDULA CORRECTA" << endl;
          
        }
    }else {
        cout << "CEDULA CORRECTA" << endl;
    }
    
    if (pay < 0) {
        cerr << "VALOR NEGATIVO DE TRANSFERENCIA O ERROR DE CEDULA" <<endl;
    }else{
        if (getSaldo() < pay) {
            cerr << "TRANSFERENCIA INSUFICIENTE" <<endl;
            
        }else{
            cout << "TRANFERENCIA EXITOSO" << endl;
            setSaldo(getSaldo()-pay);
        }
        
    }
    
    
}
