//
//  main.cpp
//  EXAMEN2
//
//  Created by Juan Cisneros on 4/21/21.
//

#include <iostream>

#include <string>
#include "Wallet.h"
using namespace std;


int main() {
    
    Wallet billetera1("Juan Francisco Cisneros",1710229392, 1000);
    billetera1.balanceWallet();
    
    billetera1.recargarWallet(5000);
    billetera1.pagarWaller(500);
    billetera1.transferirMontoWallet(17102293928, 250);
    billetera1.balanceWallet();
    
    
    

    return 0;
}
