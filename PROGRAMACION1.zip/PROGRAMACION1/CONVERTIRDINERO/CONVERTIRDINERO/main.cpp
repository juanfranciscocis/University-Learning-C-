//
//  main.cpp
//  CONVERTIRDINERO
//
//  Created by Juan Cisneros on 5/17/21.
//

#include <iostream>
#include <string>
#include <array>
using namespace::std;

int main() {
    
    //INGRESO DE DIVISAS
    array<float, 3> arrayDeDivisas;
    
    for (size_t i=0; i < arrayDeDivisas.size(); i++){
        float divisas;
        cout << "INGRESE LA COTIZACION PARA EUROS, GPB Y JPY" << endl;
        cin >> divisas;
        arrayDeDivisas[i] = divisas;
    }
    
    float usrDolares, conversionTotal=0;
    int opciones;
    string tipoDeDivisa;
    
    do {
        
        cout << "INGRESAR CANTIDAD DE DOLARES A CONVERTIR O 0 PARA SALIR" << endl;
        cin >> usrDolares;
        if (usrDolares <=0) {
            break;
        }
        
        cout << "PRECIONE 1.EUROS , 2.GPB O 3.JPY PARA CONVERTIR" << endl;
        cin >> opciones;
        
        while (true) {
            if (opciones == 1) {
                conversionTotal = arrayDeDivisas[0] * usrDolares;
                tipoDeDivisa = "EUROS";
                break;
            }else if (opciones == 2){
                conversionTotal = arrayDeDivisas[1] * usrDolares;
                tipoDeDivisa = "GPB";
                break;
            }else if (opciones == 3){
                conversionTotal = arrayDeDivisas[2] * usrDolares;
                tipoDeDivisa = "JPY";
                break;
            }else{
                cerr << "OPCION NO ENCONTRADA, REINGRESAR" << endl;
                cin >> opciones;
            }
            
        }
        
        cout << "CONVIRTIO " << usrDolares <<" DOLARES A " << tipoDeDivisa << " TOTAL: " << conversionTotal << endl;
        
        
        
        
    } while(usrDolares != 0);
    
    
    return 0;
}
