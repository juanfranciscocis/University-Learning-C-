//
//  main.cpp
//  UsoDoWhile
//
//  Created by Juan Cisneros on 5/5/21.
//

#include <iostream>
using namespace::std;

int main() {
    
    
    //Do while ejecuta una accion una o mas veces
    
    int c=1;
    /*
    do { //Haz lo siguiente DELEY UNA VEZ
        <#statements#> //Accion a repetir
    } while (<#condition#>); //Talvez Haga esto si es verdadero
     
     */
    
    
    
    do {
        cout << c << endl;
        c++;
    } while (c<=10);
    
    do {
        cout << c << " SIEMPRE SE CREA UNA VEZ EL LAZO " << endl;
        c++;
    } while (c==0);
    
    
    
    
    return 0;
}
