//
//  main.cpp
//  CANDIDATOS
//
//  Created by Juan Cisneros on 5/17/21.
//

#include <iostream>
using namespace::std;
#include <string>
#include <array>

int main(int argc, const char * argv[]) {
    
    array<string, 2> candidatos;
    array<int, 2> votos;
    
}
