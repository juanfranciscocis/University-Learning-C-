//
//  main.cpp
//  FuncionesPasoPorReferencia
//
//  Created by Juan Cisneros on 5/10/21.
//

#include <iostream>
using namespace::std;

//Declaracion de funciones

void sumaValor (int);
void sumaReferencia (int & ); //No tiene un entero pero una referencia a un entero


int main() {
    
    
    int x = 1;
    int y = 1;
    
    sumaValor(x); //Suma valor no cambia la vatiable solo la pasa al parametro de la funcion
    sumaReferencia(y); //Suma referencia modifica la variable original
    
    
    cout << "x= " <<  x << endl;
    cout << "y= " << y << endl;
    
    
    
    
    
    return 0;
}

//Defino Funciones

void sumaValor (int a){
    a+=3;
    cout << "SUMA VALOR: " <<a << endl;
}

void sumaReferencia (int & b){ //Se toma el valor al que hace referencia "b"(y) y le suma 3 (b es una referencia a un entero) ( b es otro nombre para y)
    b+=3;
    cout << "SUMA REFERENCIA:" << b << endl;
    
}
