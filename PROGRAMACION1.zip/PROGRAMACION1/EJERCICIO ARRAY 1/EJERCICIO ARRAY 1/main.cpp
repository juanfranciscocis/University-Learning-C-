//
//  main.cpp
//  EJERCICIO ARRAY 1
//
//  Created by Juan Cisneros on 5/15/21.
//

#include <iostream>
#include <array>
using namespace::std;

int main() {

    //inicializar 10 elementos de un array "counts" a 0
    /*
    array<int, 10> counts;
    
    for (size_t i=0; i<counts.size(); i++) {
        
        counts[i] = 0;
        cout << counts[i] << endl;
        
    }
    */
    
    //Agregar 1 a cada elemento de un array "bonus" de tamano 15
    
    /*
    array<int,15> bonus;
    
        //Pedir al usuario 15 numeros
    for (size_t i=0; i<bonus.size(); i++) {
        int agregarNum;
        cout << "INGRESAR 1 NUMERO ENTERO" << endl;
        cin>> agregarNum;
        
        bonus[i]=agregarNum;
        cout << "IMPRIMO ARRAY BONUS " << bonus[i] << endl;
        
        
        
        
    }
    
    cout << endl;
    
    //sumo 1 a cada elemento del array bonus
    
    for (size_t i=0; i<bonus.size(); i++) {
        
        bonus[i] +=1;
        cout << "IMPRIMO ARRAY BONUS SUMADO 1 A CADA ELEMENTO " << bonus[i] << endl;
        
    }
    */
    
    /*
    
    array<double, 12> monthlyTemperatures;
    
    for (size_t i=0; i<monthlyTemperatures.size();i++) {
        
        monthlyTemperatures[i] = i+1;
        
        
    }
    
    for (int i=0; i<12; i++) {
        int numUsr = 0;
        cout << "INGRESE UN NUMERO PARA MOSTRAR LA TEMPERATURA EN ESE MES" << endl;
        cin >> numUsr;
        
        
        cout << "Se muestra los resultados del mes "<<numUsr<< ":"<<monthlyTemperatures[numUsr] << endl;
        
        
    }
    
    
    */
    
    
    
    
    
    
    
    
    return 0;
}
