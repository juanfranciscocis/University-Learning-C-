//
//  main.cpp
//  Enteros
//
//  Created by Juan Cisneros on 2/17/21.
//

//PROGRAMA QUE MANEJA VARIABLES ENTERAS Y OPERA CON ELLAS
//EL PROGRAMA SUMA 2 NUMEROS ENTEROS INGRESADOS POR EL USUARIO

#include <iostream>

int main() {
    
//    Varibales , una Varibale es un espacio en memoria que contiene un valor para ser usado por el programa
    
//    Definicion de Variables
//    Tipo de Dato: int
//    Nombre de la Varibale
//    Operador =
//    Valor de Inicializacion
    
    int numero1 = 0; //primer entero
    int numero2 = 0; //segundo entero
    int suma = 0; //suma de enteros
    int resta; //Resta de enteros
    int mult; //Multiplicacion de enteros
    int div;// Division de enteros
    int modulo;//Residuo de la division,
    int x;
    
    
    
//    Ingreso de Datos CIN
    std::cout <<"Ingrese el primer entero \n"; //"<<" es un operador de incersion
    std::cin >> numero1; //">>" Operador de extraccion de string
    std::cout<<"Ingrese el segundo entero \n";
    std::cin >> numero2;
    
//    Suma de Datos
    suma = numero1 + numero2; //"=" Es operador de asignacion
    resta = numero1 - numero2;
    mult = numero1 * numero2;
    div = numero1 / numero2;
    modulo = numero1 % numero2;
    
// Imprimo La suma en Pantalla
    std::cout << "EL TOTAL ES DE LA SUMA: " <<suma <<std::endl;
    std::cout << "EL TOTAL ES DE LA RESTA: " << resta <<std::endl;
    std::cout << "EL TOTAL ES DE LA MULTIPLICACION : " <<mult <<std::endl;
    std::cout << "EL TOTAL ES DE LA DIVISION: " <<div <<std::endl;
    std::cout << "EL TOTAL ES DE LA MODULO: " <<modulo <<std::endl;
    
    x = numero1 * numero2 + mult % numero1;
    
    std::cout << "EL TOTAL DE UNA ECUACION ARITMETICA CUALQUIERA ES : " << x<<std::endl;
    
    
 

    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    return 0;
}

