//
//  EJERCICIO.cpp
//  Enteros
//
//  Created by Juan Cisneros on 2/22/21.
//

#include <iostream>


//    EJERCICIO
    
//    PROGRAMA QUE SOLICITE 3 ENTEROS E IMPRIMA EL PRODUCTO DE LOS MISMOS
//    SOLICITE AL USUARIO U 4TO NUMERO Y CALCULE EL MODULO DEL SEGUNDO Y DEL CUARTO NUMERO
//    CALCULE LA DIVISION DEL PRODUCTO Y MODULOS ANTERIORES

int main (){
    
//    DECLARO VARIABLES
    int numero1;
    int numero2;
    int numero3;
    int numero4;
    int producto;
    int modulo1;
    int div_Mod_Prod;
    
//    INPUT DE VARIABLES
    std::cout <<"INGRESE UN NUMERO ENTERO"<<std::endl;
    std::cin >> numero1;
    std::cout <<"INGRESE UN NUMERO ENTERO"<<std::endl;
    std::cin >> numero2;
    std::cout <<"INGRESE UN NUMERO ENTERO"<<std::endl;
    std::cin >> numero3;
    
//PRODUCTO DE LOS TRES NUMEROS
    
    producto = numero1 * numero2 * numero3;
    
//INPUT DE LA ULTIMA VARIBALE
    
    std::cout << "INGRESE UN ULTIMO NUMERO ENTERO" << std::endl;
    std::cin >> numero4;
    
//MODULO ENTRE EL SEGUNDO Y CUARTO NUMERO
    
    modulo1 = numero2 % numero4;
  
    
//DIVISION DEL PRODUCTO Y MODULOS
    
    div_Mod_Prod = producto / modulo1;
    
//IMPRIMO
    
    std::cout << "PRODUCTOS = " << producto << std::endl;
    std::cout<<" MODULO = " <<modulo1<< std::endl;
    std::cout<< " DIVISION ENTRE PRODUCTO Y MODULOS ANTERIORES " << div_Mod_Prod << std::endl;
    
    


    
    
    
    return 0;
}
