//
//  main.cpp
//  FUNCIONES EN MAIN
//
//  Created by Juan Cisneros on 5/5/21.
//

#include <iostream>
using namespace::std;
//DECLARACION DE FUNCION

float numeroMinimo (float, float ,float);

int main() {
    
    float usr1,usr2,usr3;
    cout << "INGRESAR DECIMALES" << endl;
    
    cin >> usr1;
    cin >> usr2;
    cin >> usr3;
    
    numeroMinimo(usr1, usr2, usr3);
    
    
    
    return 0;
}

float numeroMinimo (float a, float b, float c){
    
    float m =a;
    if (b < m){
        m=b;
    }else if (c < m){
        m = c;
    }
    
    return m;
}
