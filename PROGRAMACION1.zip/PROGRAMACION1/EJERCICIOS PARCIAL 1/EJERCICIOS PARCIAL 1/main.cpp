//
//  main.cpp
//  EJERCICIOS PARCIAL 1
//
//  Created by Juan Cisneros on 3/23/21.
//

#include <iostream>
using namespace std;


class Pelicula{

public:
    
    void informacionPelicula (string nombre, int anio){
        cout << "NOMBRE: " << nombre<< endl;
        cout << "ANO: " << anio<< endl;
        
    }
    
    
};


int main() {
    
//    Defino Variable e Input usuario
    string nombrePeli;
    int anioPeli;
    
    
    
    cout << "INTRODUCIR EL NOMBRE DE LA PELICULA"<< endl;
    getline(cin, nombrePeli);
    cout << "INTRODUCIR ANO"<< endl;
    cin >> anioPeli;
    
//    Creo objeto y acrtivo clase
    
    Pelicula na;
    
    na.informacionPelicula(nombrePeli, anioPeli);
    

    
    

    return 0;
}
