//
//  main.cpp
//  EJERCICIO ARRAY 2
//
//  Created by Juan Cisneros on 5/15/21.
//

#include <iostream>
#include <array>
using namespace::std;

int main() {
 

    long value1,value2;
    value1 = 200000;
    
    long *longPtr;
    
    longPtr = &value1;
    cout <<  "ESTE ES LONGPTR: "<<longPtr << " ESTA ES LA VARIABLE VALUE1: "<<&value1 << endl;
    cout << "ESTO VALE LONGPTR: " << *longPtr << endl;
    
    value2 = *longPtr;
    cout <<"VALOR DE VALUE2: " <<value2 << endl;
    cout <<"ESTE ES LONGPTR: "<<longPtr << " ESTA ES LA VARIABLE VALUE1: "<<&value1 << endl;
    
    
    
    return 0;
}
