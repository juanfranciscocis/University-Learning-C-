//
//  Computador.cpp
//  Ejercicio Computador
//
//  Created by Juan Cisneros on 5/17/21.
//

#include "Computador.h"
#include <string>
#include <iostream>
using namespace std;

Computador::Computador(std::string brand,std::string model,string cpu, int year, int ram, int price ){
    
    setAno(year);
    setMemoriaRam(ram);
    setProcesador(cpu);
    setModelo(model);
    setMarca(brand);
    setPrecio(price);
    
}


void Computador::setAno(int year){
    
    while (year <2020 or year > 2021) {
        cerr << "REINGRESE LA FECHA" << endl;
        cin >> year;
    }
    
    ano = year;
    
}

void Computador::setMemoriaRam(int ram){
    
    while (ram != 4 and ram !=8 and ram !=16) {
        cerr << "REINGRESE LA MEMORIA RAM" << endl;
        cin >> ram;
    
    }
    
    memoriaRam = ram;
}

int Computador::getAno()const{
    return ano;
}

int Computador::getMemoriaRam()const{
    return memoriaRam;
}

int Computador::getPrecio()const{
    return precio;
}

void Computador::setMarca(string brand){
    marca = brand;
}

void Computador::setModelo(string model){
    modelo = model;
}

void Computador::setPrecio(int price){
    precio = price;
}

void Computador::setProcesador(string cpu){
    procesador = cpu;
    
}

string Computador::getMarca()const{
    return marca;
}

string Computador::getModelo()const{
    return modelo;
}
string Computador::getProcesador()const{
    return procesador;
}



void Computador::mostrarDatos()const{
    
    cout << getMemoriaRam() << endl;
    cout << getAno()<< endl;
    cout << getModelo()<< endl;
    cout << getMarca()<< endl;
    cout << getPrecio()<< endl;
    cout << getProcesador() << endl;
    
    
}
