//
//  main.cpp
//  Ejercicio Computador
//
//  Created by Juan Cisneros on 5/17/21.
//

#include "Computador.h"
#include <string>
#include <iostream>
using namespace std;

void controlDePrecios(int);

int main() {
    
    string marca, modelo, procesador;
    int ano, precio, memoria;
    
    Computador computador1 ("CACA","ANO", "LOCO", 2021,4,0);
    
    //INGRESO DE COMPUTADORES
    
    do {
        cout << "INGRESE LA MARCA " << endl;
        getline(cin, marca);
        computador1.setMarca(marca);
        
        cout << "INGRESE EL MODELO" << endl;
        getline(cin, modelo);
        computador1.setModelo(modelo);
        
        cout << "INGRESE EL PROCESADOR" << endl;
        getline(cin, procesador);
        computador1.setProcesador(procesador);
        
        cout << "INGRESE ANO DE FABRICACION" << endl;
        cin >> ano;
        computador1.setAno(ano);
        
        cout << "INGRESE MEMORIA" << endl;
        cin >> memoria;
        computador1.setMemoriaRam(memoria);
        
        cout << "INGRESE EL PRECIO o 0 PARA SALIR" << endl;
        cin >> precio;
        computador1.setPrecio(precio);
        cin.ignore();
        
        if (precio !=0) {
            precio += precio;
        }
        
        
    } while (precio != 0);
    
    
    controlDePrecios(precio);
    
    
    return 0;
}

void controlDePrecios(int ingresoUsr){
    int mayor =0  , menor = -1, promedio = 0, contadorDePromedio = 0;

    
    while (ingresoUsr > 0) {
        
        if (ingresoUsr > mayor) {
            mayor = ingresoUsr;
        }
        
        if (contadorDePromedio == 0) {
            menor = ingresoUsr;
        }else {
            if (ingresoUsr < menor) {
                menor = ingresoUsr;
            }
        }
        
        while (true) {
            promedio += ingresoUsr;
            contadorDePromedio++;
            break;
            
        }
        
        break;

    }
        
        
    
    
    float total = float(promedio) / float(contadorDePromedio);
    cout << mayor << "MAYOR" << endl;
    cout << menor << "MENOR" << endl;
    cout << total << " PROMEDIO" << endl;
    
   
    
}
