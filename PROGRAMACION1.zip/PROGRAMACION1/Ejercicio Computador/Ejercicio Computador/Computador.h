//
//  Computador.h
//  Ejercicio Computador
//
//  Created by Juan Cisneros on 5/17/21.
//

#include <string>

class Computador{
public:
    Computador(std::string,std::string,std::string,int, int , int);
    
    void setMarca(std::string);
    void setModelo(std::string);
    void setAno(int);
    void setProcesador(std::string);
    void setMemoriaRam(int);
    void setPrecio(int);
    void mostrarDatos()const;

    
    std::string getMarca()const;
    std::string getModelo()const;
    int getAno()const;
    std::string getProcesador()const;
    int getMemoriaRam()const;
    int getPrecio()const;
    
    
    
    
private:
    std::string marca, modelo,procesador;
    int memoriaRam,precio, ano;
    
    
};
