//
//  main.cpp
//  ejercicio votos
//
//  Created by Juan Cisneros on 5/17/21.
//

#include <iostream>
#include <array>
using namespace::std;

int main() {
    
    array<string, 2> candidatos {"",""};
    array<int, 2> votos {0,0};
    
    for (size_t i=0; i < candidatos.size(); i++) {
        string candidatosUsr;
        cout << "INGRESE UN NOMBRE DE CANDIDATO" << endl;
        getline(cin,candidatosUsr);
        candidatos[i] = candidatosUsr;
        for (size_t c =0; c <votos.size();) {
            int votosUsr;
            cout << "INGRESE UN VOTO PARA EL CANDIDATO: " << candidatos[i] << endl;
            cin >> votosUsr;
            while (votosUsr <0) {
                cerr << "VOTOS MENORES A 0 REINGRESE PARA: " << candidatos[i] << endl;
                cin >> votosUsr;
            }
            votos[i] = votosUsr;
            cin.ignore();
            break;
        }
    }

        
    for (size_t i = 0; i < candidatos.size();i++) {
        cout << candidatos[i];
        for (size_t c= 0; c <= votos.size();) {
            cout << votos[i] << endl;
            break;
        }
    }
        
        




    
    
    
    
    
    return 0;
}
