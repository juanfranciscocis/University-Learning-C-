//
//  main.cpp
//  EJERCICIO VUELO
//
//  Created by Juan Cisneros on 4/19/21.
//

#include <iostream>
#include "Vuelo.h"
#include <string>
using namespace std;

int main() {
    
    //Crear un objeto
    
    Vuelo vuelo1("MCO", 23);
    
    vuelo1.datosVuelo();
    
    
    

    
    
    
    return 0;
}
