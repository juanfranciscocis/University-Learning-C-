//
//  Vuelo.h
//  EJERCICIO VUELO
//
//  Created by Juan Cisneros on 4/19/21.
//Dos datos miembro : string origen, int numero
//Constructor, funciones set get, datosVuelo
//Validar que origen tenga maximo 3 caracteres, caso contrario recortae
//Probar la clase creando un objeto

#include <string> //Uso de cadena de caracteres

class Vuelo{
    
public:
    //Funciones miembro- Prototipos
    
    //Constructor
    Vuelo(std::string , int);
    
    // Funciones set y get
    
    void setOrigen(std::string);
    std::string getOrigen()const;
    
    void setNumero(int);
    int getNumero()const;
    
    //Funcion datos del vuelo
    
    void datosVuelo()const;
    
private:
    //Datos miembro
    std::string origen;
    int numero;
    
    
    
};

