//
//  Vuelo.cpp
//  EJERCICIO VUELO
//
//  Created by Juan Cisneros on 4/19/21.
//

#include "Vuelo.h" //Uso de la clase Vuelo
//Directivas de preprocesamiento
#include <string>
#include <iostream> //COUT, CIN, CEER
using namespace::std;


//Constructor

Vuelo::Vuelo (string origin, int number){
    
    //Validacion
    setOrigen(origin);
    setNumero(number);

}


//Set y Get

void Vuelo::setOrigen(string origin){
//Validar que el origen tenga maximo 3 caracteres
    if (origin.size()<=3) {
        origen = origin;
    }else{
        //Mensaje al usuario
        cerr<<"ORIGEN MAXIMO 3 CARACTERES POR LO TANTO SE RECORTA"<<endl;
        //Recortar
        origen = origin.substr(0,3); //Recorto, pongo desde donde 0, hasta donde 3.
    }
    
}

string Vuelo::getOrigen()const{
    return origen;
}

void Vuelo::setNumero(int number){
    numero = number;
    
}

int Vuelo::getNumero()const{
    return numero;
}


//datosVuelo

void Vuelo::datosVuelo()const{
    cout << "ORIGEN: "<< getOrigen()<<endl;
    cout << "NUMERO DE VUELO: " <<getNumero()<<endl;
    
}






