//
//  main.cpp
//  OperadoresDeAsignacionIncrementoDecremento
//
//  Created by Juan Cisneros on 5/3/21.
//

#include <iostream>
using namespace::std;

int main() {
    int a = 3;
    
    // a = a + 5;
    a+=5;
    
    //OPERADORES DE INCREMENTO Y DECREMENTO
    
    int c = 4;
    
    //Incremento ++
    //Decremento --
    
    //POST : MODIFICA EL VALOR DE LA VARIABLE EN LA LINEA SIGUIENRE
    cout << c++ << endl;
    c =4;
    // PRE:MODIFICA EL VALOR DE LA VARIABLE EN DICHA LINEA
    cout << ++c << endl;
    
    c--;
    cout << c << endl;
    
    
    
    
    
    
    
    
}
