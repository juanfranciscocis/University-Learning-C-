#include <iostream>
#include <ctype.h>
#include <locale>


class Hotel {

public:
    Hotel(std::string name, std::string city, int category)
    {

        setNombre(name);
        setCuidad(city);
        setCategoria(category);
    }


    //DATOS HOTEL DE IMPRESION
    void datosHotel() const{
        std::cout << "DATOS DEL HOTEL" << std::endl;
        std::cout << "NOMBRE: " << getNombre() << std::endl;
        std::cout << "CIUDAD: " << getCuidad() << std::endl;
        std::cout << "CATEGORIA: " << getCategoria() << std::endl;
    }



     //GET
    std::string getNombre() const{

        return nombre;
    }

    std::string getCuidad() const {
        return cuidad;
    }

    int getCategoria() const {
        return categoria;
    }

    //SET
    void setNombre(std::string name){

        while (name.size() > 20 or name.size() == 0){
            std::cerr<<"EL NOMBRE TIENE MAS DE 20 O ES MENOR QUE 0 CARACTERES, REINGRESE:"<< std::endl;
            getline(std::cin,name);
        }

        nombre= name; //ASIGNO DATO MIEMBRO

    }

    void setCuidad(std::string city) {
        while (city != "Quito" and city != "Guayaquil" and city != "Cuenca"){
            std::cerr<<"CUIDAD NO EXISTENTE, REINGRESE"<< std::endl;
            getline(std::cin,city);
        }
        cuidad = city;
    }

    void setCategoria(int category) { //VALIDAR QUE LA CATEGORIA ESTE ENTRE 1-5
        while (category < 1 or category > 5){
            std::cerr<<"CATEGORIA NO EXISTENTE, REINGRESE"<< std::endl;
            std::cin >> category;

        }

        categoria = category;
    }


private:
    std::string nombre;
    std::string cuidad;
    int categoria = 0;



};







int main() {

    Hotel hotel("VACIO","Quito",1);
    hotel.datosHotel();
    std::cout << std::endl;

    std::string nombreUsr, ciudadUsr;
    int categoriaUsr;


    std::cout << "INGRESAR EL NOMBRE DEL HOTEL : "<< std::endl;
    getline(std::cin, nombreUsr);
    hotel.setNombre(nombreUsr);

    std::cout << "INGRESAR LA CIUDAD DEL HOTEL : "<< std::endl;
    getline(std::cin, ciudadUsr);
    hotel.setCuidad(ciudadUsr);

    std::cout << "INGRESAR CATEGORIA DEL HOTEL : " << std::endl;
    std::cin >> categoriaUsr;
    hotel.setCategoria(categoriaUsr);

    std::cout << std::endl;
    hotel.datosHotel();







    return 0;
}
