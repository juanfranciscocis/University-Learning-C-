#include "Vuelo.h"
#include <iostream>
#include <string>
using namespace std;

void funcion1 (Vuelo&);

int main ()
{
    //Creación de objeto
    Vuelo v1;
    //Impresión de datos del objeto
    v1.datosVuelo();
    
    //Otras formas de crear objetos y acceder a sus funciones
    //Referencias - alias, nickname u otro nombre para una variable/objetos
    //int a=0;
    //int& aRef=a;
    
    
    //REFERENCIA AL OBJETO V1
    Vuelo& v1Ref {v1};
    v1Ref.datosVuelo();
          

    funcion1(v1); //MODIFICO EL OBJETO V1
    
    cout << "Datos vuelo desde funcion main " << endl;
    v1.datosVuelo();
    
    //PUNTEROS A OBJETOS
    //Vuelo* v1Ptr {&v1};
    //v1Ptr->datosVuelo();
    
    
}

void funcion1 (Vuelo& x) //REFERENCIA A UN OBJETO DE LA CLASE VUELO
{
    //LO QUE HAGA CON X, MODIFICA UN OBJETO
    x.setPrecio(400);
    cout << "Datos vuelo desde funcion 1" << endl;
    x.datosVuelo();
}



