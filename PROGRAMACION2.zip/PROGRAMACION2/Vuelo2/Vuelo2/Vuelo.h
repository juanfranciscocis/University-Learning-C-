/*
 Cree una clase Vuelo que tenga cuatro datos miembro: un origen (tipo string), un destino (tipo string), una aerolínea (tipo string) y un precio (tipo int).
 Incluya un constructor con parámetros por defecto que inicialice todos los datos miembro. Incluya las respectivas funciones set/get. Escriba también una función datosVuelo que muestre en pantalla los datos del vuelo. Valide que el origen y destino no tenga más de 3 caracteres, el destino deberá ser distinto del origen. Además la aerolínea podrá ser únicamente LATAM, American o United. Finalmente, valide que el precio asignado sea siempre mayor que 250 y múltiplo de 5. Si los datos fueran inválidos, solicite nuevamente al usuario. Separe la interfaz de la clase, de su implementación.
 Pruebe en un programa la funcionalidad de la clase: cree un objeto con el constructor y muestre sus datos.
 */


#ifndef VUELO_H
#define VUELO_H

//Interfaz de la clase Vuelo
#include <string> //Cadenas de caracteres

class Vuelo
{
public:
    //Constructor
    Vuelo (std::string="UIO",std::string="GYE",std::string="LATAM",int=300);
    //Funciones set/get
    void setOrigen (std::string);
    void setDestino (std::string);
    void setAerolinea (std::string);
    void setPrecio (int);
    std::string getOrigen () const;
    std::string getDestino () const;
    std::string getAerolinea () const;
    int getPrecio () const;
    //Función impresión datos del objeto
    void datosVuelo () const;
    
private:
    //Datos miembro
    std::string origen;
    std::string destino;
    std::string aerolinea;
    int precio=0;
};

#endif
