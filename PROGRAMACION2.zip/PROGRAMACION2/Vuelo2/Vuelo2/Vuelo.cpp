/*
 Cree una clase Vuelo que tenga cuatro datos miembro: un origen (tipo string), un destino (tipo string), una aerolínea (tipo string) y un precio (tipo int).
 Incluya un constructor con parámetros por defecto que inicialice todos los datos miembro. Incluya las respectivas funciones set/get. Escriba también una función datosVuelo que muestre en pantalla los datos del vuelo. Valide que el origen y destino no tenga más de 3 caracteres, el destino deberá ser distinto del origen. Además la aerolínea podrá ser únicamente LATAM, American o United. Finalmente, valide que el precio asignado sea siempre mayor que 250 y múltiplo de 5. Si los datos fueran inválidos, solicite nuevamente al usuario. Separe la interfaz de la clase, de su implementación.
 Pruebe en un programa la funcionalidad de la clase: cree un objeto con el constructor y muestre sus datos.
 */

//Implementación de la clase Vuelo
#include "Vuelo.h"
#include <iostream>
#include <string>
using namespace std;

//:: operador de resolución de alcance

//Constructor
Vuelo::Vuelo(string o, string d, string a, int p)
{
    setOrigen(o);
    setDestino(d);
    setAerolinea(a);
    setPrecio(p);
}

//Funciones set
void Vuelo::setOrigen(string o)
{
    while (o.size()!=3)
    {
        //Mientras la longitud sea distinta de 3 caracteres se solicita reingreso
        cerr << "Origen invalido. Favor reingrese." << endl;
        getline(cin,o);
    }
    //Asignación al dato miembro
    origen=o;
}

void Vuelo::setDestino(string d)
{
    //Valide que el origen y destino no tenga más de 3 caracteres, el destino deberá ser distinto del origen.
    // origen=UIO
    // d=UIO
    while (d.size()!=3 or d==getOrigen())
    {
        //Mientras la longitud sea distinta de 3 caracteres o el destino sea igual al origen se solicita reingreso
        cerr << "Destino invalido. Favor reingrese." << endl;
        getline(cin,d);
    }
    //Asignación
    destino=d;
}

void Vuelo::setAerolinea(string a)
{
    //Además la aerolínea podrá ser únicamente LATAM, American o United.
    while (a!="LATAM" and a!="American" and a!="United")
    {
        //Mientras el valor de aerolínea no sea uno de los requeridos, se pide reingreso
        cerr << "Aerolinea invalida. Favor reingrese." << endl;
        getline (cin,a);
    }
    aerolinea=a; //Asignación dato miembro
}


void Vuelo::setPrecio(int p)
{
    //Finalmente, valide que el precio asignado sea siempre mayor que 250 y múltiplo de 5.
    //(p>250 and p%5==0)
    while (p<=250 or p%5!=0)
    {
        //Mientras el precio sea menor que 250 o no sea múltiplo de 5, se pide reingreso
        cerr << "Precio invalido. Favor reingrese." << endl;
        cin >> p;
    }
    //Asignación
    precio=p;
}


//Funciones get
string Vuelo::getOrigen()const
{
    return origen; //Retorna origen
}

string Vuelo::getDestino()const
{
    return destino; //Retorna destino
}

string Vuelo::getAerolinea()const
{
    return aerolinea; //Retorna aerolinea
}

int Vuelo::getPrecio() const
{
    return precio; //retorna precio
}


//Función que imprime datod del objeto
void Vuelo::datosVuelo()const
{
    cout << "Datos vuelo:" << endl;
    cout << "Origen: " << getOrigen() << endl;
    cout << "Destino: " << getDestino() << endl;
    cout << "Aerolinea: " << getAerolinea() << endl;
    cout << "Precio: " << getPrecio() << endl;

}
