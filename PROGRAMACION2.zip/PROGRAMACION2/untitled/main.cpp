#include <iostream>
#include "Punto.h"
int main() {

    Punto p1(2);
    std::cout << p1.getA();





    std::cout << "Hello, World!" << std::endl;

    std::cout << "JUAN FRANCISCO CISNEROS" << std::endl;


    return 0;
}
