//
// Created by Juan Cisneros on 12/29/21.
//

#ifndef UNTITLED_PUNTO_H
#define UNTITLED_PUNTO_H



class Punto {
public:
    Punto(int);

    void setA (int);

    int getA () const;

    virtual void hola();


private:
    int a;

};


#endif //UNTITLED_PUNTO_H
