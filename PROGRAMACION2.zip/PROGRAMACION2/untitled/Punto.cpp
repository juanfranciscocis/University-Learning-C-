//
// Created by Juan Cisneros on 12/29/21.
//

#include "Punto.h"


Punto::Punto(int a) {
    setA(a);

}


void Punto::setA(int a) {
    this->a = a;

}

int Punto::getA() const {
    return a;
}