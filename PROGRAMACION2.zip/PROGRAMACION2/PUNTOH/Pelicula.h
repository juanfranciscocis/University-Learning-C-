//
// Created by Juan Cisneros on 9/22/21.
//

#ifndef PUNTOH_PELICULA_H
#define PUNTOH_PELICULA_H
#include "Pelicula.h"


class Pelicula {

};


#endif //PUNTOH_PELICULA_H
