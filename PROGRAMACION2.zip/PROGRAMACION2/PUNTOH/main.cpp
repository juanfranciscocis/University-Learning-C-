#include <iostream>
#include "Pelicula.h"
#include "Pelicula.cpp"

int main() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
