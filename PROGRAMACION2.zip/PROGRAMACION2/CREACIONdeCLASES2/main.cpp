#include <iostream>

class Celular { //Mayuscula

public: //funciones que pueden ser usadas fuera de la clase
    //funciones miembro - COMPORTAMIENTOS

    //DEFINIR FUNCION MIEMBRO QUE IMPRIME TEXTO EN PANTALLA
    void textInScreen() const {
        std::cout<< "INFORMACION DEL CELULAR" << std::endl;
        std::cout << "MARCA: " << getMarca() << std::endl;
        std::cout << "PRECIO: " << getPrecio() << std::endl;
    }

    // FUNCIONES GET - OBTENER EL VALOR DEL DATO MIEMBRO MARCA
    std::string getMarca() const {
        return marca;
    }

    float getPrecio() const {
        return precio;
    }

    //FUNCIONES SET - ASIGNA EL VALOR DEL DATO MIEMBRO
    void setMarca(std::string brand) {
        marca = brand;
    }

    void setPrecio(float price) {
        precio = price;
    }


private: //funciones dentro de la clase
    //datos miembro - CARACTERISTICAS
    std::string marca;
    float precio;


};



int main() {

    //Creacion/instanciacion
    Celular cel1; //objeto
    std::string brandUsr; //Variable
    float priceUsr;

    std::cout << "INGRESAR MARCA:" << std::endl;
    getline(std::cin, brandUsr); //input del usuario

    std::cout << "INGRESAR PRECIO:" << std::endl;
    std::cin >> priceUsr; //input del usuario

    cel1.setMarca(brandUsr); //seteo de la marca ingresada al dato miembro
    cel1.setPrecio(priceUsr); //seteo del precio de la marca ingresada al dato miembro
    cel1.textInScreen(); //uso de la funcion para impresion










    return 0;
}





