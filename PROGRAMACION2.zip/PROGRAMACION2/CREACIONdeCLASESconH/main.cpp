#include <iostream>
#include "Pelicula.h"



int main() {
    Pelicula pelicula("NOMBRE","FOX","ACCION",2010,100,1);
    pelicula.datosPelicula();







    return 0;
}
