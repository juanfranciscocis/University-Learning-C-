//
// Created by Juan Cisneros on 9/15/21.
//

#include <string>

class Pelicula {

private:
    std::string nombre, estudio, genero;
    int anoDePublicacion, duracionMin;
    double precio;

public:
    //CONSTRUCTOR
    Pelicula(std::string, std::string , std::string , int , int , double );

    //Funciones GET
    std::string getNombre() const;

    std::string getEstudio() const;

    std::string getGenero() const;

    int getAnoDePublicacion() const;

    int getDuracionMin() const;

    double getPrecio() const;

    //Funciones SET
    void setNombre(std::string name);

    void setEstudio(std::string studio);

    void setGenero( std::string gender);

    void setAnoDePublicacion(int yearOfPublication);

    void setDuracionMin(int durationMin);

    void setPrecio(double price);

    //FUNCION DATOS

    void datosPelicula() const;

};


