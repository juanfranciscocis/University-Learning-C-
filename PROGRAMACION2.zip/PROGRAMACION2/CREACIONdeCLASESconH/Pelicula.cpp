//
// Created by Juan Cisneros on 9/15/21.
//

#include "Pelicula.h"
#include "iostream"

//CONSTRUCTOR
Pelicula::Pelicula(std::string name, std::string studio, std::string gender,
                   int yearPublication , int duration, double price) {
    setNombre(name);
    setEstudio(studio);
    setGenero(gender);
    setAnoDePublicacion(yearPublication);
    setDuracionMin(duration);
    setPrecio(price);

}

//Funciones GET
std::string Pelicula::getNombre() const {
    return nombre;
}

std::string Pelicula::getEstudio() const {
    return estudio;
}

std::string Pelicula::getGenero() const {
    return genero;
}

int Pelicula::getAnoDePublicacion() const {
    return anoDePublicacion;
}

int Pelicula::getDuracionMin() const {
    return duracionMin;
}

double Pelicula::getPrecio() const {
    return precio;
}

void Pelicula::setNombre(std::string name){
    while (name.size() > 40 or name.size()<=0){
        std::cerr << "REINGRESAR EL NOMBRE, MUY LARGO O CERO" << std::endl;
        getline(std::cin,name);
    }
    nombre = name;
}

void Pelicula::setEstudio(std::string studio) {
    while (studio!= "FOX" and studio != "UNIVERSAL" and studio !="WARNER"){
        std::cerr << "REINGRESAR EL ESTUDIO, FOX , UNIVERSAL , WARNER" << std::endl;
        getline(std::cin,studio);
    }
    estudio =studio;
}

void Pelicula::setGenero(std::string gender) {
    while (gender!= "ACCION" and gender != "DRAMA" and gender !="TERROR" and gender != "COMEDIA") {
        std::cerr << "REINGRESAR EL GENERO" << std::endl;
        getline(std::cin, gender);
    }
    genero = gender;
}

void Pelicula::setAnoDePublicacion(int yearOfPublication) {
    while (yearOfPublication < 2010 or yearOfPublication > 2021){
        std::cerr << "REINGRESAR EL ANO DE PUBLICACION" << std::endl;
        std::cin >> yearOfPublication;

    }
    anoDePublicacion = yearOfPublication;
}

void Pelicula::setDuracionMin(int durationMin) {
    while (durationMin < 100){
        std::cerr << "DURACION MENOR A 100 MINUTOS" << std::endl;
        std::cin >> durationMin;
    }
    duracionMin = durationMin;
}

void Pelicula::setPrecio(double price) {
    while (price <= 0){
        std::cerr << "PRECIO MENOR O IGUAL A CERO REINGRESE" << std::endl;
        std::cin >> price;

    }

    precio = price;
}

//DATOS PELICULA

void Pelicula::datosPelicula() const {
    std::cout << "NOMBRE PELICULA: " << getNombre() << std::endl;
    std::cout << "GENERO PELICULA: " << getGenero() << std::endl;
    std::cout << "ESTUDIO PELICULA: " << getEstudio() << std::endl;
    std::cout << "ANO DE PUBLICACION PELICULA: " << getAnoDePublicacion() << std::endl;
    std::cout << "DURACION PELICULA: " << getDuracionMin() << std::endl;
    std::cout << "PRECIO PELICULA: " << getPrecio() << std::endl;

}
