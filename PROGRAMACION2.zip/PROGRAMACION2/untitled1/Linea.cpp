//
// Created by Juan Cisneros on 12/29/21.
//

#include "Linea.h"



void Linea::getLinea() const {
    std::cout << "P1: " << p1.getHola() << std::endl;
    std::cout << "P2: " << p2.getHola() << std::endl;
    std::cout << "HOLA: " << p1.setHola(3) << std::endl;

}

const Punto &Linea::getP1() const {
    return p1;
}

void Linea::setP1(const Punto &p1) {
    Linea::p1 = p1;
}

const Punto &Linea::getP2() const {
    return p2;
}

void Linea::setP2(const Punto &p2) {
    Linea::p2 = p2;
}

Linea::Linea(const Punto &p1, const Punto &p2) : p1(p1), p2(p2) {

}
