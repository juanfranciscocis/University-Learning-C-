//
// Created by Juan Cisneros on 12/29/21.
//

#include "Punto.h"

Punto::Punto(int hola){
    setHola(hola);
}

int Punto::getHola() const {
    return hola;
}

void Punto::setHola(int hola) {
    this->hola = hola;
}
