#include <iostream>
#include "Punto.h"
#include "Linea.h"
int main() {
    Linea l1({1},{2});

    l1.getLinea();




    return 0;
}
