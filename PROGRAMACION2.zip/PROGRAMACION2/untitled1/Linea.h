//
// Created by Juan Cisneros on 12/29/21.
//

#ifndef UNTITLED1_LINEA_H
#define UNTITLED1_LINEA_H
#include "Punto.h"

class Linea {
public:
    Linea(const Punto &p1, const Punto &p2);

    void getLinea()const;

    const Punto &getP1() const;

    void setP1(const Punto &p1);

    const Punto &getP2() const;

    void setP2(const Punto &p2);

private:
    Punto p1;
    Punto p2;


};


#endif //UNTITLED1_LINEA_H
