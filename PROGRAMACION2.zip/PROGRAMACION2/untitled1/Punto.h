//
// Created by Juan Cisneros on 12/29/21.
//

#ifndef UNTITLED1_PUNTO_H
#define UNTITLED1_PUNTO_H
#include <iostream>


class Punto {
    friend class Linea;
public:
    Punto(int = 0);

    int getHola() const;

    void setHola(int);

private:
    int hola;


};


#endif //UNTITLED1_PUNTO_H
