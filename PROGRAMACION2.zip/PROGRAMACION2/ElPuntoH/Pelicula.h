//
// Created by Juan Cisneros on 9/20/21.
//
#include <string>


class Pelicula {
public:
    //FUNCIONES MIEMBRO
    //CONSTRUCTOR
    Pelicula(std::string, int, float );

    //GET Y SET
    std::string getNombre() const;

    void setNombre(std::string);

    int getAno() const;

    void setAno(int);

    float getPrecio() const;

    void setPrecio(float precio);

    //OBTNER TODOS LOS DATOS
    void dataPelicula ()const;


private:
    //  DATOS MIEMBRO
    std::string nombre;
    int ano;
    float precio;


};


