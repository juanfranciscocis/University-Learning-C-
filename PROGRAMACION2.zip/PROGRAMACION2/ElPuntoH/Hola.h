//
// Created by Juan Cisneros on 9/22/21.
//

#ifndef ELPUNTOH_HOLA_H
#define ELPUNTOH_HOLA_H


class Hola {
private:
    int hola;

public:
    Hola(int hola);

    int getHola() const;

    void setHola(int hola);

};


#endif //ELPUNTOH_HOLA_H
