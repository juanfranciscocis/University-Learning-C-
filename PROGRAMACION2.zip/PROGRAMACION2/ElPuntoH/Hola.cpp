//
// Created by Juan Cisneros on 9/22/21.
//

#include "Hola.h"

hola = 90;

int Hola::getHola() const {
    return hola;
}

void Hola::setHola(int hola) {
    Hola::hola = hola;
}

Hola::Hola(int hola) : hola(hola) {}
