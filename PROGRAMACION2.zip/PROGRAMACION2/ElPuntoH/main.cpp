#include <iostream>

#include "Pelicula.cpp"
#include "Hola.h"




int main() {

    Pelicula pelicula("DEFAULT");
    pelicula.dataPelicula();

    Hola hola1(0);
    hola1.setHola(0);










    return 0;

}
