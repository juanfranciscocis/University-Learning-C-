//
// Created by Juan Cisneros on 9/20/21.
//

#include "Pelicula.h"



//IMPLEMENTACION
//CONSTRUCTOR
Pelicula::Pelicula(std::string name, int year = 2010, float price = 90) {
    setNombre(name);
    setAno(year);
    setPrecio(price);
}

//GET Y SET
 std::string Pelicula::getNombre() const {
    return nombre;
}

void Pelicula::setNombre( std::string name) {
    while (name.size() > 20){ //max 20 caracteres
        std::cerr << "NOMBRE MAYOR A 20 CARACTERES FAVOR REINGRESE" << std::endl;
        getline(std::cin,name);
    }

    nombre = name;
}

int Pelicula::getAno() const {
    return ano;
}

void Pelicula::setAno(int year) {
    while (year <2010 or year > 2021){
        std::cerr << "ANO FUERA DE RANGO, REINGRESE" << std::endl;
        std::cin >> year;
    }
    ano = year;
}

float Pelicula::getPrecio() const {
    return precio;
}

void Pelicula::setPrecio(float price) {
    while (price <=0){
        std::cerr << "PRECIO ES MENOR O IGUAL A 0, REINGRESE" << std::endl;
        std::cin.ignore();
        std::cin >> price;
    }

    precio = price;
}

void Pelicula::dataPelicula() const {
    std::cout << "NOMBRE DE LA PELICULA " << getNombre() << std::endl;
    std::cout << "ANO DE SALIDA DE PELICULA " << getAno() << std::endl;
    std::cout << "PRECIO DE LA PELICULA $" << getPrecio() << std::endl;
}
