//
// Created by Juan Cisneros on 9/29/21.
//

#ifndef HOLA_JUAN_H
#define HOLA_JUAN_H




class juan {

public:
    juan(std::string);

    std::string getJuano()const;

    int getA() const;

    void setA(int a);

private:
    std::string juano;


    int a;
};


#endif //HOLA_JUAN_H
