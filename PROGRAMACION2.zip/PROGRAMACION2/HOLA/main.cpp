#include <iostream>
#include "juan.h"


int main() {
    std::cout << "Hello, World!" << std::endl;

    juan juan1("jefhjds");
    std::cout << juan1.getJuano() << std::endl;

    return 0;
}
