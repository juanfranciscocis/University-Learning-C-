//
// Created by Juan Cisneros on 9/29/21.
//

#include "juan.h"
#include <iostream>



juan::juan(std::string juans) {
    juano = juans;
}


std::string juan::getJuano()const{
    return juano;
}


int juan::getA() const {
    return a;
}

void juan::setA(int a) {
    juan::a = a;
}
