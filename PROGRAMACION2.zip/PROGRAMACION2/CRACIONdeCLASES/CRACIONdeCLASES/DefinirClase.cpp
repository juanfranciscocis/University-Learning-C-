//
//  DefinirClase.cpp
//  CRACIONdeCLASES
//
//  Created by Juan Cisneros on 8/25/21.
//

#include <stdio.h>


//DEFINO CALSE CELULAR
class Celular { //NOMBRE DE LA CLASE EN MAYUSCULA
    
    
//ESPECIFICADORES DE ACCESO
public: //PUEDE SER USADO FUERA DE LA CLASE
    //FUNCIONES MIEMBRO
    //LAS FUNCIONES MIEMBRO USAN ESTOS DATOS MIEMBRO
    
    
    
    
    
    
private: //SOLO ES USADO DENTRO DE LA CLASE
    //DATOS MIEMBRO
    int ano;
    
    
    
    
    
    
    
};
