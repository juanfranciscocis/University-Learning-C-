//
//  main.cpp
//  CRACIONdeCLASES
//
//  Created by Juan Cisneros on 8/25/21.
//

#include <iostream>
#include "DefinirClase.cpp"

int main(int argc, const char * argv[]) {
    
    
    Celular celular1;
    
    
    return 0;
}
